# Security Specification: MangaVault Firestore ABAC Rules

## 1. Data Invariants
1. **User Sandboxing**: All user manga items and settings are strictly isolated under `/users/{userId}/*`. A user can only read, create, update, or delete documents inside their own `{userId}` path where `request.auth.uid == userId`.
2. **Immutable Identity**: `userId` in `incoming()` must always match `request.auth.uid` and path variable `{userId}`.
3. **Validated Schema**: Mandatory fields (`id`, `userId`, `title`, `coverUrl`, `sourceUrl`, `readingStatus`) must exist, be of correct type, and conform to maximum boundary limits.
4. **No Blanket Access**: Non-authenticated users or cross-user queries cannot read or tamper with another user's library or preferences.
5. **Atomic Consistency**: During updates, the owner ID cannot be transferred or spoofed.

## 2. The "Dirty Dozen" Payloads (Adversarial Tests)
1. **Unauthenticated Read**: Anonymous/Unauthenticated user attempts `GET /users/userA/mangas/manga1` -> Expected: PERMISSION_DENIED.
2. **Cross-User Hijack**: User B tries to read `GET /users/userA/mangas/manga1` -> Expected: PERMISSION_DENIED.
3. **Cross-User Creation**: User B tries to create `/users/userA/mangas/manga2` with `userId: 'userB'` or `userId: 'userA'` -> Expected: PERMISSION_DENIED.
4. **Missing Required Fields**: User A tries to create `/users/userA/mangas/manga1` without `title` or `coverUrl` -> Expected: PERMISSION_DENIED.
5. **ID Poisoning / Huge String**: User A attempts to write a 1MB payload in `title` or `synopsis` -> Expected: PERMISSION_DENIED.
6. **Path Injection / Invalid ID**: Attempting to use a non-alphanumeric or path-traversal ID -> Expected: PERMISSION_DENIED.
7. **Identity Spoofing on Update**: User A attempts to update `/users/userA/mangas/manga1` setting `userId: 'userB'` -> Expected: PERMISSION_DENIED.
8. **Invalid Enum Injection**: User A tries to update `readingStatus` to `"hacked"` -> Expected: PERMISSION_DENIED.
9. **Ghost Field Injection**: User A adds unauthorized administrative shadow field `isAdmin: true` -> Expected: PERMISSION_DENIED.
10. **Cross-User Settings Modification**: User B tries to write `/users/userA/settings/preferences` -> Expected: PERMISSION_DENIED.
11. **Excessive Genres Array Attack**: User A attempts to submit an array with 1000 items in `genres` -> Expected: PERMISSION_DENIED.
12. **Blanket Query Scraping**: User attempts collectionGroup query across all users' manga -> Expected: PERMISSION_DENIED.
