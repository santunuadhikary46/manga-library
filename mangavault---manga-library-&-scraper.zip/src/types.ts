export type ReadingStatus = 'reading' | 'completed' | 'plan_to_read' | 'on_hold' | 'dropped';

export interface MangaItem {
  id: string;
  userId: string;
  title: string;
  originalTitle?: string;
  coverUrl: string;
  sourceUrl: string;
  sourceSite: string;
  author: string;
  artist?: string;
  synopsis: string;
  genres: string[];
  status: 'ongoing' | 'completed' | 'hiatus' | 'unknown';
  isAdult: boolean;
  totalChapters?: number | null;
  currentChapter: number;
  rating: number; // 0 to 10
  readingStatus: ReadingStatus;
  notes?: string;
  isFavorite: boolean;
  demographic?: string;
  createdAt: string;
  updatedAt: string;
}

export type LayoutView = 'grid' | 'list' | 'cards';

export interface UserSettings {
  userId: string;
  wallpaperType: 'preset' | 'custom';
  wallpaperValue: string; // preset ID or custom image URL / data URL
  wallpaperOpacity: number; // 0 to 1 (dark overlay factor)
  wallpaperBlur: number; // 0 to 20 px
  themeColor: string; // hex color or preset name
  layoutView: LayoutView;
  allowAdultContent: boolean; // 18+ toggle
  enableEntranceAnimation: boolean;
  updatedAt: string;
}

export interface ScrapedMangaResponse {
  title: string;
  originalTitle?: string;
  author: string;
  artist?: string;
  synopsis: string;
  coverUrl: string;
  genres: string[];
  status: 'ongoing' | 'completed' | 'hiatus' | 'unknown';
  isAdult: boolean;
  totalChapters?: number | null;
  rating: number;
  demographic?: string;
  sourceSite: string;
  sourceUrl: string;
}
