import { collection, doc, setDoc, deleteDoc, onSnapshot, getDocs, getDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, User } from './firebase';
import { MangaItem, UserSettings } from '../types';

const LOCAL_STORAGE_MANGA_KEY = 'mangavault_local_mangas';
const LOCAL_STORAGE_SETTINGS_KEY = 'mangavault_local_settings';

export const DEFAULT_SETTINGS: UserSettings = {
  userId: 'guest',
  wallpaperType: 'preset',
  wallpaperValue: 'cyberpunk',
  wallpaperOpacity: 0.75,
  wallpaperBlur: 3,
  themeColor: '#e11d48', // rose-600
  layoutView: 'grid',
  allowAdultContent: true, // User requested adult content support
  enableEntranceAnimation: true,
  updatedAt: new Date().toISOString(),
};

export const INITIAL_SAMPLE_MANGAS: Omit<MangaItem, 'userId'>[] = [
  {
    id: 'solo-leveling-demo',
    title: 'Solo Leveling',
    originalTitle: '나 혼자만 레벨업 (Na Honjaman Rebeleop)',
    coverUrl: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=700&auto=format&fit=crop&q=80',
    sourceUrl: 'https://asuracomic.net',
    sourceSite: 'Asura Scan',
    author: 'Chugong',
    artist: 'DUBU (REDICE STUDIO)',
    synopsis: 'In a world where hunters, humans with supernatural powers, must battle deadly monsters to protect mankind, Sung Jinwoo, a notoriously weak hunter, finds himself in a struggle for survival in a double dungeon.',
    genres: ['Action', 'Fantasy', 'Monsters', 'Supernatural', 'System'],
    status: 'completed',
    isAdult: false,
    totalChapters: 200,
    currentChapter: 179,
    rating: 9.8,
    readingStatus: 'reading',
    notes: 'Legendary shadow monarch awakening! Chapter 179 was peak art.',
    isFavorite: true,
    demographic: 'Seinen',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'berserk-demo',
    title: 'Berserk',
    originalTitle: 'ベルセルク (Beruseruku)',
    coverUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=700&auto=format&fit=crop&q=80',
    sourceUrl: 'https://mangadex.org',
    sourceSite: 'MangaDex',
    author: 'Kentaro Miura',
    artist: 'Kentaro Miura',
    synopsis: 'Guts, a former mercenary known as the "Black Swordsman," seeks revenge against his former master Griffith and the God Hand in a dark, brutal dark-fantasy world.',
    genres: ['Action', 'Dark Fantasy', 'Horror', 'Tragedy', 'Psychological', 'Mature'],
    status: 'ongoing',
    isAdult: true, // 18+ adult series
    totalChapters: 375,
    currentChapter: 115,
    rating: 9.9,
    readingStatus: 'reading',
    notes: 'The Golden Age arc is an unmatched masterpiece in manga history.',
    isFavorite: true,
    demographic: 'Mature / 18+',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'one-piece-demo',
    title: 'One Piece',
    originalTitle: 'ONE PIECE (ワンピース)',
    coverUrl: 'https://images.unsplash.com/photo-1563089145-599997674d42?w=700&auto=format&fit=crop&q=80',
    sourceUrl: 'https://mangaplus.shueisha.co.jp',
    sourceSite: 'MangaPlus',
    author: 'Eiichiro Oda',
    artist: 'Eiichiro Oda',
    synopsis: 'Monkey D. Luffy sets out with his pirate crew, the Straw Hat Pirates, across the Grand Line in search of the world\'s ultimate treasure known as One Piece.',
    genres: ['Action', 'Adventure', 'Comedy', 'Shounen', 'Fantasy'],
    status: 'ongoing',
    isAdult: false,
    totalChapters: 1125,
    currentChapter: 1110,
    rating: 9.7,
    readingStatus: 'reading',
    notes: 'Egghead Island revelations! Gear 5 mastery.',
    isFavorite: true,
    demographic: 'Shounen',
    createdAt: new Date(Date.now() - 172800000).toISOString(),
    updatedAt: new Date(Date.now() - 172800000).toISOString(),
  }
];

// Local Storage helpers
export function getLocalMangas(): MangaItem[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_MANGA_KEY);
    if (!raw) {
      const seeded = INITIAL_SAMPLE_MANGAS.map(m => ({ ...m, userId: 'guest' }));
      localStorage.setItem(LOCAL_STORAGE_MANGA_KEY, JSON.stringify(seeded));
      return seeded;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Error reading local mangas', e);
    return [];
  }
}

export function saveLocalMangas(mangas: MangaItem[]) {
  try {
    localStorage.setItem(LOCAL_STORAGE_MANGA_KEY, JSON.stringify(mangas));
  } catch (e) {
    console.error('Error saving local mangas', e);
  }
}

export function getLocalSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    return DEFAULT_SETTINGS;
  }
}

export function saveLocalSettings(settings: UserSettings) {
  try {
    localStorage.setItem(LOCAL_STORAGE_SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Error saving local settings', e);
  }
}

// Add Manga item
export async function addMangaToStorage(
  mangaData: Omit<MangaItem, 'id' | 'userId' | 'createdAt' | 'updatedAt'>,
  user: User | null
): Promise<MangaItem> {
  const id = 'manga_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 7);
  const now = new Date().toISOString();
  const userId = user ? user.uid : 'guest';

  const newManga: MangaItem = {
    ...mangaData,
    id,
    userId,
    createdAt: now,
    updatedAt: now,
  };

  // If user is authenticated, save directly to Firestore
  if (user) {
    const path = `users/${user.uid}/mangas/${id}`;
    try {
      const docRef = doc(db, 'users', user.uid, 'mangas', id);
      await setDoc(docRef, newManga);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  }

  // Also maintain local copy for fast hydration
  const localList = getLocalMangas();
  saveLocalMangas([newManga, ...localList]);
  return newManga;
}

// Update Manga item
export async function updateMangaInStorage(
  id: string,
  updates: Partial<MangaItem>,
  user: User | null
): Promise<void> {
  const now = new Date().toISOString();

  if (user) {
    const path = `users/${user.uid}/mangas/${id}`;
    try {
      const docRef = doc(db, 'users', user.uid, 'mangas', id);
      await setDoc(docRef, { ...updates, updatedAt: now }, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  }

  const localList = getLocalMangas();
  const index = localList.findIndex(m => m.id === id);
  if (index !== -1) {
    localList[index] = { ...localList[index], ...updates, updatedAt: now };
    saveLocalMangas(localList);
  }
}

// Delete Manga item
export async function deleteMangaFromStorage(
  id: string,
  user: User | null
): Promise<void> {
  if (user) {
    const path = `users/${user.uid}/mangas/${id}`;
    try {
      const docRef = doc(db, 'users', user.uid, 'mangas', id);
      await deleteDoc(docRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  }

  const localList = getLocalMangas().filter(m => m.id !== id);
  saveLocalMangas(localList);
}

// Sync local mangas to cloud on login
export async function syncLocalToCloud(user: User): Promise<void> {
  const path = `users/${user.uid}/mangas`;
  try {
    const querySnapshot = await getDocs(collection(db, 'users', user.uid, 'mangas'));
    const cloudMangas: MangaItem[] = [];
    querySnapshot.forEach((d) => {
      cloudMangas.push(d.data() as MangaItem);
    });

    const localList = getLocalMangas();

    // Push local manga that don't exist in cloud yet
    for (const localM of localList) {
      const existsInCloud = cloudMangas.some(cm => cm.sourceUrl === localM.sourceUrl || cm.id === localM.id);
      if (!existsInCloud && localM.title) {
        const docRef = doc(db, 'users', user.uid, 'mangas', localM.id);
        const toSave = { ...localM, userId: user.uid };
        await setDoc(docRef, toSave);
      }
    }
  } catch (err) {
    console.warn('Sync to cloud warning:', err);
  }
}

// Save Settings
export async function saveUserSettingsToStorage(
  settings: Partial<UserSettings>,
  user: User | null
): Promise<UserSettings> {
  const current = getLocalSettings();
  const updated: UserSettings = {
    ...current,
    ...settings,
    userId: user ? user.uid : 'guest',
    updatedAt: new Date().toISOString(),
  };

  saveLocalSettings(updated);

  if (user) {
    const path = `users/${user.uid}/settings/preferences`;
    try {
      const docRef = doc(db, 'users', user.uid, 'settings', 'preferences');
      await setDoc(docRef, updated, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  }

  return updated;
}
