export interface WallpaperPreset {
  id: string;
  name: string;
  thumbnail: string;
  url: string;
  description: string;
  themeAccent: string;
}

export const WALLPAPER_PRESETS: WallpaperPreset[] = [
  {
    id: 'cyberpunk',
    name: 'Neo-Tokyo Cyberpunk',
    thumbnail: 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=1920&auto=format&fit=crop&q=85',
    description: 'Electric neon rain, cyberpunk anime streets of Shinjuku',
    themeAccent: '#e11d48', // rose-600
  },
  {
    id: 'manga-ink',
    name: 'Manga Ink & Screentone',
    thumbnail: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=1920&auto=format&fit=crop&q=85',
    description: 'Classic monochrome manga panels with rich ink halftones',
    themeAccent: '#f59e0b', // amber-500
  },
  {
    id: 'cherry-blossom',
    name: 'Cherry Blossom Twilight',
    thumbnail: 'https://images.unsplash.com/photo-1528164344705-475426879c0d?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1528164344705-475426879c0d?w=1920&auto=format&fit=crop&q=85',
    description: 'Moody violet sakura dusk with glowing Japanese lanterns',
    themeAccent: '#ec4899', // pink-500
  },
  {
    id: 'velvet-midnight',
    name: 'Velvet Midnight Slate',
    thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1920&auto=format&fit=crop&q=85',
    description: 'Deep minimalist obsidian waves for maximum reader focus',
    themeAccent: '#06b6d4', // cyan-500
  },
  {
    id: 'anime-retro',
    name: '90s Retro Anime Aesthetic',
    thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1920&auto=format&fit=crop&q=85',
    description: 'Warm nostalgic twilight anime glow with soft pastel sky',
    themeAccent: '#8b5cf6', // purple-500
  },
  {
    id: 'cosmic-void',
    name: 'Cosmic Stellar Abyss',
    thumbnail: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=300&auto=format&fit=crop&q=80',
    url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=1920&auto=format&fit=crop&q=85',
    description: 'Vibrant celestial deep space nebulae with glowing stars',
    themeAccent: '#10b981', // emerald-500
  },
];

export const THEME_ACCENTS = [
  { name: 'Manga Crimson', hex: '#e11d48', ring: 'ring-rose-500' },
  { name: 'Neon Amber', hex: '#f59e0b', ring: 'ring-amber-500' },
  { name: 'Cyber Cyan', hex: '#06b6d4', ring: 'ring-cyan-500' },
  { name: 'Amethyst Purple', hex: '#8b5cf6', ring: 'ring-purple-500' },
  { name: 'Emerald Jade', hex: '#10b981', ring: 'ring-emerald-500' },
  { name: 'Sakura Pink', hex: '#ec4899', ring: 'ring-pink-500' },
];
