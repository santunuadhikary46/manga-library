import React, { useState, useEffect, useMemo } from 'react';
import { collection, onSnapshot, doc } from 'firebase/firestore';
import { auth, googleProvider, signInWithPopup, signOut, onAuthStateChanged, User, db, handleFirestoreError, OperationType } from './lib/firebase';
import { MangaItem, UserSettings, ReadingStatus, LayoutView } from './types';
import {
  getLocalMangas,
  getLocalSettings,
  addMangaToStorage,
  updateMangaInStorage,
  deleteMangaFromStorage,
  saveUserSettingsToStorage,
  syncLocalToCloud,
  DEFAULT_SETTINGS
} from './lib/storage';
import { WALLPAPER_PRESETS } from './lib/wallpapers';
import { SplashAnimation } from './components/SplashAnimation';
import { Navbar } from './components/Navbar';
import { MangaCard } from './components/MangaCard';
import { MangaModal } from './components/MangaModal';
import { AddMangaModal } from './components/AddMangaModal';
import { WallpaperCustomizer } from './components/WallpaperCustomizer';
import { BookOpen, Sparkles, Filter, ArrowUpDown, Plus, ShieldAlert, Heart, CheckCircle2, Cloud, ExternalLink, X, AlertTriangle } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [mangas, setMangas] = useState<MangaItem[]>([]);
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);

  // Modals and UI states
  const [selectedManga, setSelectedManga] = useState<MangaItem | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const [authErrorMessage, setAuthErrorMessage] = useState<string | null>(null);

  // Filters & Sorting
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'reading' | 'completed' | 'plan_to_read' | 'favorites'>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'rating' | 'title' | 'chapters'>('recent');

  // Load initial settings and mangas from local cache
  useEffect(() => {
    const cachedSettings = getLocalSettings();
    setSettings(cachedSettings);
    setShowSplash(cachedSettings.enableEntranceAnimation);

    const cachedMangas = getLocalMangas();
    setMangas(cachedMangas);
  }, []);

  // Listen to Auth state and Firestore synchronization
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);

      if (user) {
        // Sync local entries to cloud on sign-in
        await syncLocalToCloud(user);

        // Firestore Real-time listener for Manga library
        const mangasCollectionRef = collection(db, 'users', user.uid, 'mangas');
        const unsubscribeMangas = onSnapshot(
          mangasCollectionRef,
          (snapshot) => {
            const list: MangaItem[] = [];
            snapshot.forEach((docSnap) => {
              list.push(docSnap.data() as MangaItem);
            });
            // If user has saved mangas in cloud, use them; else keep local
            if (list.length > 0) {
              setMangas(list);
            }
            setLoading(false);
          },
          (err) => {
            handleFirestoreError(err, OperationType.GET, `users/${user.uid}/mangas`);
          }
        );

        // Firestore Real-time listener for User settings
        const settingsDocRef = doc(db, 'users', user.uid, 'settings', 'preferences');
        const unsubscribeSettings = onSnapshot(
          settingsDocRef,
          (docSnap) => {
            if (docSnap.exists()) {
              setSettings((prev) => ({ ...prev, ...(docSnap.data() as UserSettings) }));
            }
          },
          (err) => {
            console.warn('Could not read cloud settings:', err);
          }
        );

        return () => {
          unsubscribeMangas();
          unsubscribeSettings();
        };
      } else {
        // Fallback to local storage for guests
        setMangas(getLocalMangas());
        setLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Compute active background wallpaper
  const activeWallpaperUrl = useMemo(() => {
    if (settings.wallpaperType === 'custom' && settings.wallpaperValue) {
      return settings.wallpaperValue;
    }
    const preset = WALLPAPER_PRESETS.find((p) => p.id === settings.wallpaperValue);
    return preset ? preset.url : WALLPAPER_PRESETS[0].url;
  }, [settings.wallpaperType, settings.wallpaperValue]);

  // Handle Google Sign In
  const handleSignIn = async () => {
    try {
      setAuthErrorMessage(null);
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      console.warn('Google Sign-in status:', error);
      const msg = error?.message || String(error);
      if (
        msg.includes('missing initial state') ||
        msg.includes('sessionStorage') ||
        msg.includes('storage-partitioned') ||
        msg.includes('auth/missing-initial-state')
      ) {
        setAuthErrorMessage(
          'Browser Storage Partitioning detected: Because this app is running inside a preview iframe, your browser blocks cross-origin sessionStorage for OAuth popups. Click "Open in Standalone Tab" below to complete Google Sign-In in a direct window!'
        );
      } else if (msg.includes('popup-closed-by-user') || msg.includes('cancelled-popup-request')) {
        // User closed popup, no error needed
      } else {
        setAuthErrorMessage(msg || 'Google Sign-In could not be completed.');
      }
    }
  };

  // Handle Sign Out
  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setMangas(getLocalMangas());
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  // Manga Operations
  const handleAddManga = async (mangaData: Omit<MangaItem, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
    const created = await addMangaToStorage(mangaData, currentUser);
    setMangas((prev) => [created, ...prev.filter((m) => m.id !== created.id)]);
  };

  const handleUpdateManga = async (id: string, updates: Partial<MangaItem>) => {
    await updateMangaInStorage(id, updates, currentUser);
    setMangas((prev) =>
      prev.map((m) => (m.id === id ? { ...m, ...updates, updatedAt: new Date().toISOString() } : m))
    );
    if (selectedManga && selectedManga.id === id) {
      setSelectedManga((prev) => (prev ? { ...prev, ...updates } : null));
    }
  };

  const handleDeleteManga = async (id: string) => {
    await deleteMangaFromStorage(id, currentUser);
    setMangas((prev) => prev.filter((m) => m.id !== id));
    if (selectedManga && selectedManga.id === id) {
      setSelectedManga(null);
    }
  };

  const handleSaveSettings = async (newSettings: Partial<UserSettings>) => {
    const updated = await saveUserSettingsToStorage(newSettings, currentUser);
    setSettings(updated);
  };

  // Filter & Sort logic
  const filteredMangas = useMemo(() => {
    return mangas.filter((m) => {
      // Adult content filter check
      if (!settings.allowAdultContent && m.isAdult) {
        return false;
      }

      // Search match
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = m.title.toLowerCase().includes(query);
        const matchesAuthor = m.author.toLowerCase().includes(query);
        const matchesGenre = m.genres.some((g) => g.toLowerCase().includes(query));
        const matchesOriginal = m.originalTitle?.toLowerCase().includes(query);
        if (!matchesTitle && !matchesAuthor && !matchesGenre && !matchesOriginal) {
          return false;
        }
      }

      // Category filter
      if (activeFilter === 'reading') return m.readingStatus === 'reading';
      if (activeFilter === 'completed') return m.readingStatus === 'completed';
      if (activeFilter === 'plan_to_read') return m.readingStatus === 'plan_to_read';
      if (activeFilter === 'favorites') return m.isFavorite;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'title') return a.title.localeCompare(b.title);
      if (sortBy === 'chapters') return (b.currentChapter || 0) - (a.currentChapter || 0);
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    });
  }, [mangas, settings.allowAdultContent, searchQuery, activeFilter, sortBy]);

  // Counters
  const counts = useMemo(() => {
    const list = settings.allowAdultContent ? mangas : mangas.filter((m) => !m.isAdult);
    return {
      all: list.length,
      reading: list.filter((m) => m.readingStatus === 'reading').length,
      completed: list.filter((m) => m.readingStatus === 'completed').length,
      plan_to_read: list.filter((m) => m.readingStatus === 'plan_to_read').length,
      favorites: list.filter((m) => m.isFavorite).length,
    };
  }, [mangas, settings.allowAdultContent]);

  return (
    <div className="relative min-h-screen text-neutral-100 flex flex-col font-sans selection:bg-rose-500 selection:text-white">
      {/* Background Wallpaper Layer */}
      <div
        className="fixed inset-0 z-0 bg-cover bg-center transition-all duration-700 pointer-events-none"
        style={{
          backgroundImage: `url(${activeWallpaperUrl})`,
          filter: `blur(${settings.wallpaperBlur}px)`,
        }}
      />

      {/* Dark Overlay with customizable opacity */}
      <div
        className="fixed inset-0 z-0 bg-neutral-950 pointer-events-none transition-opacity duration-300"
        style={{ opacity: settings.wallpaperOpacity }}
      />

      {/* Opening Splash Animation */}
      {showSplash && (
        <SplashAnimation
          onComplete={() => setShowSplash(false)}
          accentColor={settings.themeColor}
        />
      )}

      {/* Main Content Area */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Navigation Bar */}
        <Navbar
          user={currentUser}
          onSignIn={handleSignIn}
          onSignOut={handleSignOut}
          onOpenAddModal={() => setIsAddModalOpen(true)}
          onOpenCustomizer={() => setIsCustomizerOpen(true)}
          onReplayIntro={() => setShowSplash(true)}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          allowAdultContent={settings.allowAdultContent}
          onToggleAdult={() => handleSaveSettings({ allowAdultContent: !settings.allowAdultContent })}
          layoutView={settings.layoutView}
          onChangeLayout={(v) => handleSaveSettings({ layoutView: v })}
          accentColor={settings.themeColor}
        />

        {/* Main Library View */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
          {/* Quick Hero Banner / Paste URL CTA */}
          <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-neutral-950/90 via-neutral-900/80 to-neutral-950/90 border border-neutral-800/80 backdrop-blur-xl shadow-2xl overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center md:text-left max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-neutral-800/80 text-neutral-300 border border-neutral-700/60 mb-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Smart Manga Intelligence Engine</span>
                {currentUser ? (
                  <span className="text-emerald-400 flex items-center gap-1 ml-1">
                    • <Cloud className="w-3 h-3 inline" /> Cloud Active
                  </span>
                ) : (
                  <span className="text-neutral-400 ml-1">• Local Storage</span>
                )}
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                Your Manga & Webtoon Universe
              </h2>
              <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
                Paste any manga link to automatically scrape the full synopsis, author, tags, and authentic cover art.
                Click any manga to read live on the source website or export offline packages.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="w-full sm:w-auto px-6 py-3.5 rounded-2xl text-xs sm:text-sm font-bold text-white shadow-xl transition-all duration-200 hover:scale-105 active:scale-95 flex items-center justify-center gap-2"
                style={{ backgroundColor: settings.themeColor }}
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Paste Manga URL</span>
              </button>
            </div>
          </div>

          {/* Filter Tabs & Sort Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-800/80 pb-4">
            {/* Category Pills */}
            <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
              <button
                onClick={() => setActiveFilter('all')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
                  activeFilter === 'all'
                    ? 'bg-white text-black shadow-md'
                    : 'bg-neutral-900/80 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                All ({counts.all})
              </button>
              <button
                onClick={() => setActiveFilter('reading')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
                  activeFilter === 'reading'
                    ? 'bg-white text-black shadow-md'
                    : 'bg-neutral-900/80 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                Reading ({counts.reading})
              </button>
              <button
                onClick={() => setActiveFilter('completed')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
                  activeFilter === 'completed'
                    ? 'bg-white text-black shadow-md'
                    : 'bg-neutral-900/80 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                Completed ({counts.completed})
              </button>
              <button
                onClick={() => setActiveFilter('plan_to_read')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
                  activeFilter === 'plan_to_read'
                    ? 'bg-white text-black shadow-md'
                    : 'bg-neutral-900/80 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                Plan to Read ({counts.plan_to_read})
              </button>
              <button
                onClick={() => setActiveFilter('favorites')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition shrink-0 flex items-center gap-1 ${
                  activeFilter === 'favorites'
                    ? 'bg-rose-600 text-white shadow-md'
                    : 'bg-neutral-900/80 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                <Heart className="w-3.5 h-3.5 fill-current" />
                <span>Favorites ({counts.favorites})</span>
              </button>
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
              <span className="text-xs text-neutral-500 flex items-center gap-1">
                <ArrowUpDown className="w-3.5 h-3.5" />
                <span>Sort:</span>
              </span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-1.5 rounded-xl bg-neutral-900/90 border border-neutral-800 text-xs text-neutral-300 font-medium focus:outline-none focus:border-neutral-700"
              >
                <option value="recent">Recently Updated</option>
                <option value="rating">Highest Rated</option>
                <option value="title">Title (A-Z)</option>
                <option value="chapters">Chapters Read</option>
              </select>
            </div>
          </div>

          {/* Manga Grid / List View */}
          {filteredMangas.length > 0 ? (
            <div
              className={
                settings.layoutView === 'grid'
                  ? 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6'
                  : settings.layoutView === 'list'
                  ? 'flex flex-col gap-3'
                  : 'grid grid-cols-1 md:grid-cols-2 gap-6'
              }
            >
              {filteredMangas.map((manga) => (
                <MangaCard
                  key={manga.id}
                  manga={manga}
                  view={settings.layoutView}
                  onOpenDetails={(m) => setSelectedManga(m)}
                  onUpdate={handleUpdateManga}
                  accentColor={settings.themeColor}
                />
              ))}
            </div>
          ) : (
            /* Empty State */
            <div className="py-20 px-4 rounded-3xl bg-neutral-950/60 border border-neutral-800/80 backdrop-blur-md text-center max-w-lg mx-auto space-y-4">
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto text-white shadow-xl"
                style={{ backgroundColor: settings.themeColor }}
              >
                <BookOpen className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">No Manga Found</h3>
                <p className="text-xs text-neutral-400">
                  {searchQuery
                    ? `No titles matched "${searchQuery}". Try a different keyword.`
                    : 'Your library is empty in this category. Add a manga by pasting any URL!'}
                </p>
              </div>
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="px-5 py-2.5 rounded-xl text-xs font-bold text-white shadow-lg transition inline-flex items-center gap-1.5"
                style={{ backgroundColor: settings.themeColor }}
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Paste Manga URL</span>
              </button>
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className="mt-auto border-t border-neutral-850 bg-neutral-950/90 py-6 text-center text-xs text-neutral-500">
          <p>MangaVault • Personal Manga Library &amp; Scraper • Click titles to read directly on source</p>
        </footer>
      </div>

      {/* Modals */}
      <AddMangaModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddManga={handleAddManga}
        accentColor={settings.themeColor}
      />

      <MangaModal
        manga={selectedManga}
        isOpen={Boolean(selectedManga)}
        onClose={() => setSelectedManga(null)}
        onUpdate={handleUpdateManga}
        onDelete={handleDeleteManga}
        accentColor={settings.themeColor}
      />

      <WallpaperCustomizer
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        onTriggerIntro={() => setShowSplash(true)}
      />

      {/* Storage Partitioning / Sign-In Helper Modal */}
      {authErrorMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-700/80 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Browser Storage Partitioning</h3>
                  <p className="text-xs text-neutral-400">Preview Iframe Google Sign-In Fix</p>
                </div>
              </div>
              <button
                onClick={() => setAuthErrorMessage(null)}
                className="p-1.5 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-neutral-300 leading-relaxed bg-neutral-950 p-3.5 rounded-2xl border border-neutral-800/80">
              {authErrorMessage}
            </p>

            <div className="flex flex-col gap-2 pt-1">
              <button
                onClick={() => {
                  window.open(window.location.href, '_blank', 'noopener,noreferrer');
                  setAuthErrorMessage(null);
                }}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-white shadow-lg transition flex items-center justify-center gap-2"
                style={{ backgroundColor: settings.themeColor }}
              >
                <ExternalLink className="w-4 h-4" />
                <span>Open in Standalone Tab to Sign In</span>
              </button>
              <button
                onClick={() => setAuthErrorMessage(null)}
                className="w-full py-2 px-4 rounded-xl text-xs font-medium bg-neutral-800 hover:bg-neutral-750 text-neutral-300 transition"
              >
                Stay in Local Storage Mode (Everything Saved)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
