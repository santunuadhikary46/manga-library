import React, { useState } from 'react';
import { X, Image, Sliders, Palette, LayoutGrid, Check, Sparkles, Upload, Play, ShieldAlert } from 'lucide-react';
import { UserSettings, LayoutView } from '../types';
import { WALLPAPER_PRESETS, THEME_ACCENTS } from '../lib/wallpapers';

interface WallpaperCustomizerProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onSaveSettings: (settings: Partial<UserSettings>) => Promise<void>;
  onTriggerIntro: () => void;
}

export const WallpaperCustomizer: React.FC<WallpaperCustomizerProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onTriggerIntro,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'wallpaper' | 'theme' | 'view'>('wallpaper');
  const [customUrl, setCustomUrl] = useState(settings.wallpaperType === 'custom' ? settings.wallpaperValue : '');
  const [opacity, setOpacity] = useState(settings.wallpaperOpacity);
  const [blur, setBlur] = useState(settings.wallpaperBlur);
  const [themeColor, setThemeColor] = useState(settings.themeColor);
  const [layoutView, setLayoutView] = useState<LayoutView>(settings.layoutView);
  const [allowAdultContent, setAllowAdultContent] = useState(settings.allowAdultContent);
  const [enableEntranceAnimation, setEnableEntranceAnimation] = useState(settings.enableEntranceAnimation);

  const handleSelectPreset = async (presetId: string, defaultAccent?: string) => {
    const updates: Partial<UserSettings> = {
      wallpaperType: 'preset',
      wallpaperValue: presetId,
    };
    if (defaultAccent) {
      updates.themeColor = defaultAccent;
      setThemeColor(defaultAccent);
    }
    await onSaveSettings(updates);
  };

  const handleApplyCustomUrl = async () => {
    if (!customUrl.trim()) return;
    await onSaveSettings({
      wallpaperType: 'custom',
      wallpaperValue: customUrl.trim(),
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setCustomUrl(dataUrl);
        await onSaveSettings({
          wallpaperType: 'custom',
          wallpaperValue: dataUrl,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleOpacityChange = async (val: number) => {
    setOpacity(val);
    await onSaveSettings({ wallpaperOpacity: val });
  };

  const handleBlurChange = async (val: number) => {
    setBlur(val);
    await onSaveSettings({ wallpaperBlur: val });
  };

  const handleThemeChange = async (hex: string) => {
    setThemeColor(hex);
    await onSaveSettings({ themeColor: hex });
  };

  const handleLayoutChange = async (view: LayoutView) => {
    setLayoutView(view);
    await onSaveSettings({ layoutView: view });
  };

  const handleAdultToggle = async () => {
    const nextVal = !allowAdultContent;
    setAllowAdultContent(nextVal);
    await onSaveSettings({ allowAdultContent: nextVal });
  };

  const handleAnimationToggle = async () => {
    const nextVal = !enableEntranceAnimation;
    setEnableEntranceAnimation(nextVal);
    await onSaveSettings({ enableEntranceAnimation: nextVal });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center text-white shadow"
              style={{ backgroundColor: themeColor }}
            >
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">App Customization & Wallpapers</h2>
              <p className="text-xs text-neutral-400">Personalize your manga reader atmosphere</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-neutral-800 bg-neutral-950/40 px-6 pt-2">
          <button
            onClick={() => setActiveTab('wallpaper')}
            className={`pb-3 px-3 text-xs font-bold transition border-b-2 flex items-center gap-2 ${
              activeTab === 'wallpaper'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
            style={{ borderColor: activeTab === 'wallpaper' ? themeColor : 'transparent' }}
          >
            <Image className="w-4 h-4" />
            <span>Wallpapers</span>
          </button>
          <button
            onClick={() => setActiveTab('theme')}
            className={`pb-3 px-3 text-xs font-bold transition border-b-2 flex items-center gap-2 ${
              activeTab === 'theme'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
            style={{ borderColor: activeTab === 'theme' ? themeColor : 'transparent' }}
          >
            <Sliders className="w-4 h-4" />
            <span>Theme & Accents</span>
          </button>
          <button
            onClick={() => setActiveTab('view')}
            className={`pb-3 px-3 text-xs font-bold transition border-b-2 flex items-center gap-2 ${
              activeTab === 'view'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
            style={{ borderColor: activeTab === 'view' ? themeColor : 'transparent' }}
          >
            <LayoutGrid className="w-4 h-4" />
            <span>Display & Adult Filter</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          {activeTab === 'wallpaper' && (
            <div className="space-y-6">
              {/* Preset Wallpapers */}
              <div className="space-y-3">
                <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  Curated Anime & Manga Wallpapers
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {WALLPAPER_PRESETS.map((preset) => {
                    const isSelected = settings.wallpaperType === 'preset' && settings.wallpaperValue === preset.id;
                    return (
                      <div
                        key={preset.id}
                        onClick={() => handleSelectPreset(preset.id, preset.themeAccent)}
                        className={`group relative rounded-2xl overflow-hidden aspect-video border-2 transition cursor-pointer shadow-md ${
                          isSelected ? 'border-white scale-[1.02]' : 'border-neutral-800 hover:border-neutral-700'
                        }`}
                      >
                        <img
                          src={preset.thumbnail}
                          alt={preset.name}
                          className="w-full h-full object-cover transition duration-300 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent p-2.5 flex flex-col justify-end">
                          <span className="text-[11px] font-bold text-white truncate leading-tight">
                            {preset.name}
                          </span>
                        </div>
                        {isSelected && (
                          <div
                            className="absolute top-2 right-2 w-5 h-5 rounded-full flex items-center justify-center text-white text-xs shadow"
                            style={{ backgroundColor: themeColor }}
                          >
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Custom Image URL or Upload */}
              <div className="space-y-3 pt-3 border-t border-neutral-800">
                <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  Custom Wallpaper URL or Local Image
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={customUrl}
                    onChange={(e) => setCustomUrl(e.target.value)}
                    placeholder="Paste image URL (https://...)"
                    className="flex-1 px-3.5 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none"
                  />
                  <button
                    onClick={handleApplyCustomUrl}
                    className="px-4 py-2.5 rounded-xl text-xs font-bold text-white transition shadow"
                    style={{ backgroundColor: themeColor }}
                  >
                    Apply
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium border border-neutral-700 transition">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload Local Wallpaper File</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Sliders for Opacity and Blur */}
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-4">
                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-neutral-400">Background Dim / Dark Overlay</span>
                    <span className="font-bold text-white">{Math.round(opacity * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="0.95"
                    step="0.05"
                    value={opacity}
                    onChange={(e) => handleOpacityChange(parseFloat(e.target.value))}
                    className="w-full accent-rose-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-neutral-400">Background Blur Effect</span>
                    <span className="font-bold text-white">{blur}px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="20"
                    step="1"
                    value={blur}
                    onChange={(e) => handleBlurChange(parseInt(e.target.value))}
                    className="w-full accent-rose-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'theme' && (
            <div className="space-y-6">
              <div className="space-y-3">
                <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  Select Accent Color
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {THEME_ACCENTS.map((accent) => {
                    const isSelected = themeColor.toLowerCase() === accent.hex.toLowerCase();
                    return (
                      <button
                        key={accent.name}
                        onClick={() => handleThemeChange(accent.hex)}
                        className={`flex items-center gap-3 p-3 rounded-2xl bg-neutral-950 border transition text-left ${
                          isSelected ? 'border-white ring-1 ring-white' : 'border-neutral-800 hover:border-neutral-700'
                        }`}
                      >
                        <div
                          className="w-5 h-5 rounded-full shrink-0 shadow"
                          style={{ backgroundColor: accent.hex }}
                        />
                        <span className="text-xs font-bold text-white truncate">{accent.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Entrance Animation Trigger */}
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>App Entrance Animation</span>
                  </h4>
                  <p className="text-[11px] text-neutral-400">Play dramatic Japanese Kanji intro when opening app</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={onTriggerIntro}
                    className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-white transition flex items-center gap-1"
                  >
                    <Play className="w-3 h-3" />
                    <span>Preview</span>
                  </button>
                  <button
                    onClick={handleAnimationToggle}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      enableEntranceAnimation
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-neutral-800 text-neutral-400'
                    }`}
                  >
                    {enableEntranceAnimation ? 'Enabled' : 'Disabled'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'view' && (
            <div className="space-y-6">
              {/* Default View Mode */}
              <div className="space-y-3">
                <label className="block text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  Manga Library Layout
                </label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => handleLayoutChange('grid')}
                    className={`p-3.5 rounded-2xl border text-center transition ${
                      layoutView === 'grid'
                        ? 'bg-neutral-850 border-white text-white'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-xs mb-1">Poster Grid</div>
                    <div className="text-[10px] text-neutral-500">Visual manga covers</div>
                  </button>

                  <button
                    onClick={() => handleLayoutChange('list')}
                    className={`p-3.5 rounded-2xl border text-center transition ${
                      layoutView === 'list'
                        ? 'bg-neutral-850 border-white text-white'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-xs mb-1">Compact List</div>
                    <div className="text-[10px] text-neutral-500">Quick progress rows</div>
                  </button>

                  <button
                    onClick={() => handleLayoutChange('cards')}
                    className={`p-3.5 rounded-2xl border text-center transition ${
                      layoutView === 'cards'
                        ? 'bg-neutral-850 border-white text-white'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-xs mb-1">Magazine Deck</div>
                    <div className="text-[10px] text-neutral-500">Large cards & synopsis</div>
                  </button>
                </div>
              </div>

              {/* Adult / 18+ Mature Filter Toggle */}
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-500" />
                    <span>Adult / 18+ Content Display</span>
                  </h4>
                  <p className="text-[11px] text-neutral-400">
                    Allow viewing mature, ecchi, gore, and adult series in library
                  </p>
                </div>
                <button
                  onClick={handleAdultToggle}
                  className={`px-4 py-1.5 rounded-xl text-xs font-bold transition shadow ${
                    allowAdultContent
                      ? 'bg-rose-600 text-white'
                      : 'bg-neutral-800 text-neutral-400'
                  }`}
                >
                  {allowAdultContent ? '🔞 Allowed' : 'Hidden'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-neutral-800 bg-neutral-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl text-xs font-bold text-white shadow-lg transition"
            style={{ backgroundColor: themeColor }}
          >
            Apply & Close
          </button>
        </div>
      </div>
    </div>
  );
};
