import React, { useState } from 'react';
import { X, ExternalLink, Download, Heart, Trash2, Star, BookOpen, Check, ShieldAlert, Sparkles, FileText, Globe, Image } from 'lucide-react';
import confetti from 'canvas-confetti';
import { MangaItem, ReadingStatus } from '../types';
import { downloadCoverImage, downloadMangaDossier, downloadMangaJson, downloadOfflineReaderBundle } from '../lib/downloadHelper';

interface MangaModalProps {
  manga: MangaItem | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (id: string, updates: Partial<MangaItem>) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  accentColor: string;
}

export const MangaModal: React.FC<MangaModalProps> = ({
  manga,
  isOpen,
  onClose,
  onUpdate,
  onDelete,
  accentColor,
}) => {
  if (!isOpen || !manga) return null;

  const [currentChapter, setCurrentChapter] = useState(manga.currentChapter);
  const [readingStatus, setReadingStatus] = useState<ReadingStatus>(manga.readingStatus);
  const [rating, setRating] = useState(manga.rating);
  const [notes, setNotes] = useState(manga.notes || '');
  const [isFavorite, setIsFavorite] = useState(manga.isFavorite);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const handleChapterStep = async (delta: number) => {
    const nextVal = Math.max(0, currentChapter + delta);
    setCurrentChapter(nextVal);
    await onUpdate(manga.id, { currentChapter: nextVal });

    if (manga.totalChapters && nextVal >= manga.totalChapters && readingStatus !== 'completed') {
      setReadingStatus('completed');
      await onUpdate(manga.id, { currentChapter: nextVal, readingStatus: 'completed' });
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    }
  };

  const handleSaveProgress = async () => {
    setIsSaving(true);
    await onUpdate(manga.id, {
      currentChapter,
      readingStatus,
      rating,
      notes,
      isFavorite,
    });
    setIsSaving(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleDelete = async () => {
    await onDelete(manga.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Top Banner with cover blurred backdrop */}
        <div className="relative h-44 sm:h-56 overflow-hidden bg-neutral-950">
          <img
            src={`/api/proxy-image?url=${encodeURIComponent(manga.coverUrl)}`}
            alt=""
            className="w-full h-full object-cover blur-2xl opacity-35 scale-110"
            onError={(e) => {
              (e.target as HTMLImageElement).src = manga.coverUrl;
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-neutral-900/60 to-transparent" />

          {/* Close & Action Buttons */}
          <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
            <button
              onClick={() => {
                const nextFav = !isFavorite;
                setIsFavorite(nextFav);
                onUpdate(manga.id, { isFavorite: nextFav });
              }}
              className={`p-2.5 rounded-full backdrop-blur-md border transition ${
                isFavorite
                  ? 'bg-rose-950/80 border-rose-600 text-rose-400'
                  : 'bg-black/40 border-neutral-700/60 text-neutral-300 hover:text-white'
              }`}
              title={isFavorite ? 'Remove Favorite' : 'Add to Favorites'}
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2.5 rounded-full bg-black/40 border border-neutral-700/60 text-neutral-300 hover:text-white backdrop-blur-md transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="relative px-6 sm:px-8 pb-8 -mt-24 sm:-mt-28 space-y-6">
          {/* Main Info Row */}
          <div className="flex flex-col sm:flex-row gap-6">
            {/* Poster / Cover Art */}
            <div className="relative w-40 h-60 sm:w-48 sm:h-72 shrink-0 rounded-2xl overflow-hidden border-2 border-neutral-700/80 bg-neutral-950 shadow-2xl mx-auto sm:mx-0 group">
              <img
                src={`/api/proxy-image?url=${encodeURIComponent(manga.coverUrl)}`}
                alt={manga.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = manga.coverUrl;
                }}
              />
              {manga.isAdult && (
                <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-rose-600/95 text-[10px] font-black text-white flex items-center gap-1 shadow-md">
                  <ShieldAlert className="w-3 h-3" />
                  18+ ADULT
                </div>
              )}
              {/* Quick Cover Download Button on Cover */}
              <button
                onClick={() => downloadCoverImage(manga.coverUrl, manga.title)}
                className="absolute bottom-2.5 right-2.5 px-2.5 py-1.5 rounded-xl bg-black/85 hover:bg-black text-white text-xs font-semibold backdrop-blur-md opacity-0 group-hover:opacity-100 transition shadow-lg flex items-center gap-1.5"
                title="Download full quality cover image"
              >
                <Image className="w-3.5 h-3.5" />
                <span>Save Cover</span>
              </button>
            </div>

            {/* Title, Badges, Direct Read Button */}
            <div className="flex-1 space-y-3.5 pt-2">
              <div>
                <h1 className="text-2xl sm:text-3xl font-black text-white leading-tight">
                  {manga.title}
                </h1>
                {manga.originalTitle && (
                  <p className="text-sm text-neutral-400 italic mt-0.5">{manga.originalTitle}</p>
                )}
              </div>

              {/* Status and Meta Badges */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider bg-neutral-800 text-neutral-200 border border-neutral-700">
                  ● {manga.status}
                </span>
                <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                  <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                  {rating} / 10
                </span>
                <span className="px-2.5 py-1 rounded-lg text-xs font-medium bg-neutral-800/80 text-neutral-300">
                  {manga.demographic || 'Seinen'}
                </span>
                <span className="px-2.5 py-1 rounded-lg text-xs font-medium bg-neutral-800/80 text-neutral-300">
                  Source: {manga.sourceSite}
                </span>
              </div>

              {/* Author / Artist */}
              <div className="text-xs text-neutral-400">
                <span>By <strong className="text-neutral-200">{manga.author}</strong></span>
                {manga.artist && manga.artist !== manga.author && (
                  <span className="ml-2">| Art by <strong className="text-neutral-200">{manga.artist}</strong></span>
                )}
              </div>

              {/* Genre Pills */}
              <div className="flex flex-wrap gap-1.5">
                {manga.genres.map((g) => (
                  <span
                    key={g}
                    className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-neutral-800/90 text-neutral-300 border border-neutral-700/60"
                  >
                    {g}
                  </span>
                ))}
              </div>

              {/* PRIMARY READ ON SOURCE WEBSITE BUTTON */}
              <div className="pt-2">
                <a
                  href={manga.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2.5 w-full sm:w-auto px-6 py-3 rounded-xl text-sm font-bold text-white shadow-xl transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
                  style={{ backgroundColor: accentColor }}
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Read Now on {manga.sourceSite}</span>
                  <ExternalLink className="w-4 h-4 ml-1 opacity-80" />
                </a>
              </div>
            </div>
          </div>

          {/* Reading Tracker Bar */}
          <div className="p-5 rounded-2xl bg-neutral-950/80 border border-neutral-800 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center justify-between">
              <span>Your Reading Progress</span>
              {manga.totalChapters ? (
                <span className="text-neutral-500">
                  {Math.round((currentChapter / manga.totalChapters) * 100)}% Complete
                </span>
              ) : null}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Status */}
              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1.5">Library Status</label>
                <select
                  value={readingStatus}
                  onChange={(e) => setReadingStatus(e.target.value as ReadingStatus)}
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-white focus:outline-none"
                >
                  <option value="reading">Currently Reading</option>
                  <option value="completed">Completed</option>
                  <option value="plan_to_read">Plan to Read</option>
                  <option value="on_hold">On Hold</option>
                  <option value="dropped">Dropped</option>
                </select>
              </div>

              {/* Chapter Tracker with Steppers */}
              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1.5">
                  Chapters Read (Total: {manga.totalChapters ?? 'Ongoing'})
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleChapterStep(-1)}
                    disabled={currentChapter <= 0}
                    className="w-9 h-9 rounded-xl bg-neutral-850 hover:bg-neutral-800 disabled:opacity-40 text-neutral-200 font-bold transition flex items-center justify-center border border-neutral-700"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="0"
                    max={manga.totalChapters || 9999}
                    value={currentChapter}
                    onChange={(e) => setCurrentChapter(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-20 text-center py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-white font-bold focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleChapterStep(1)}
                    className="w-9 h-9 rounded-xl bg-neutral-850 hover:bg-neutral-800 text-neutral-200 font-bold transition flex items-center justify-center border border-neutral-700"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Star Rating */}
              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1.5">Your Score (0 - 10)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="1"
                    max="10"
                    step="0.5"
                    value={rating}
                    onChange={(e) => setRating(parseFloat(e.target.value))}
                    className="w-full accent-rose-500 cursor-pointer"
                  />
                  <span className="text-xs font-bold text-amber-400 w-8">{rating}</span>
                </div>
              </div>
            </div>

            {/* Personal Notes */}
            <div>
              <label className="block text-[11px] font-medium text-neutral-400 mb-1.5">
                Personal Notes & Review
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Write your thoughts, favorite arcs, or reminder notes..."
                className="w-full px-3.5 py-2.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none resize-none"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              {saveSuccess ? (
                <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Progress saved!
                </span>
              ) : <div />}

              <button
                type="button"
                onClick={handleSaveProgress}
                disabled={isSaving}
                className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 transition"
              >
                {isSaving ? 'Saving...' : 'Save Updates'}
              </button>
            </div>
          </div>

          {/* Synopsis */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400">Synopsis</h3>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed bg-neutral-950/40 p-4 rounded-2xl border border-neutral-800/60 whitespace-pre-line">
              {manga.synopsis}
            </p>
          </div>

          {/* DOWNLOADS & EXPORT TOOLKIT */}
          <div className="space-y-2.5 pt-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span>Download & Offline Export Options</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
              {/* 1. Download Cover */}
              <button
                onClick={() => downloadCoverImage(manga.coverUrl, manga.title)}
                className="p-3 rounded-xl bg-neutral-950 hover:bg-neutral-850 border border-neutral-800 text-left transition group"
              >
                <div className="flex items-center gap-2 text-white font-semibold text-xs mb-1 group-hover:text-rose-400">
                  <Image className="w-4 h-4 text-neutral-400 group-hover:text-rose-400" />
                  <span>Download Cover</span>
                </div>
                <p className="text-[10px] text-neutral-500">Full quality JPG/PNG poster</p>
              </button>

              {/* 2. Download Offline Bundle */}
              <button
                onClick={() => downloadOfflineReaderBundle(manga)}
                className="p-3 rounded-xl bg-neutral-950 hover:bg-neutral-850 border border-neutral-800 text-left transition group"
              >
                <div className="flex items-center gap-2 text-white font-semibold text-xs mb-1 group-hover:text-rose-400">
                  <Globe className="w-4 h-4 text-neutral-400 group-hover:text-rose-400" />
                  <span>Offline HTML</span>
                </div>
                <p className="text-[10px] text-neutral-500">Standalone browser reader file</p>
              </button>

              {/* 3. Download Dossier */}
              <button
                onClick={() => downloadMangaDossier(manga)}
                className="p-3 rounded-xl bg-neutral-950 hover:bg-neutral-850 border border-neutral-800 text-left transition group"
              >
                <div className="flex items-center gap-2 text-white font-semibold text-xs mb-1 group-hover:text-rose-400">
                  <FileText className="w-4 h-4 text-neutral-400 group-hover:text-rose-400" />
                  <span>Reader Dossier</span>
                </div>
                <p className="text-[10px] text-neutral-500">Formatted summary & notes .txt</p>
              </button>

              {/* 4. Download JSON */}
              <button
                onClick={() => downloadMangaJson(manga)}
                className="p-3 rounded-xl bg-neutral-950 hover:bg-neutral-850 border border-neutral-800 text-left transition group"
              >
                <div className="flex items-center gap-2 text-white font-semibold text-xs mb-1 group-hover:text-rose-400">
                  <Download className="w-4 h-4 text-neutral-400 group-hover:text-rose-400" />
                  <span>JSON Metadata</span>
                </div>
                <p className="text-[10px] text-neutral-500">Structured data backup file</p>
              </button>
            </div>
          </div>

          {/* Footer with Delete Option */}
          <div className="pt-4 border-t border-neutral-800/80 flex items-center justify-between">
            {confirmDelete ? (
              <div className="flex items-center gap-2">
                <span className="text-xs text-rose-400">Delete permanently?</span>
                <button
                  onClick={handleDelete}
                  className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition"
                >
                  Yes, Remove
                </button>
                <button
                  onClick={() => setConfirmDelete(false)}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 text-xs transition"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setConfirmDelete(true)}
                className="inline-flex items-center gap-1.5 text-xs text-neutral-500 hover:text-rose-400 transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remove From Library</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl text-xs font-semibold bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
