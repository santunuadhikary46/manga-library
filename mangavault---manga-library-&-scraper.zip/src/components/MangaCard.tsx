import React, { useState, useRef, useEffect } from 'react';
import {
  ExternalLink,
  Heart,
  ShieldAlert,
  Star,
  BookOpen,
  Download,
  Plus,
  CheckCircle2,
  MoreVertical,
  Copy,
  Check,
  Info,
  Sparkles,
  RotateCcw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { MangaItem, LayoutView, ReadingStatus } from '../types';
import { downloadCoverImage } from '../lib/downloadHelper';

interface MangaCardProps {
  manga: MangaItem;
  view: LayoutView;
  onOpenDetails: (manga: MangaItem) => void;
  onUpdate: (id: string, updates: Partial<MangaItem>) => Promise<void>;
  accentColor: string;
}

export const MangaCard: React.FC<MangaCardProps> = ({
  manga,
  view,
  onOpenDetails,
  onUpdate,
  accentColor,
}) => {
  const [showContextMenu, setShowContextMenu] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close context menu on outside click
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowContextMenu(false);
      }
    };
    if (showContextMenu) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [showContextMenu]);

  // Toggle Favorite
  const handleToggleFavorite = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextFavorite = !manga.isFavorite;
    await onUpdate(manga.id, { isFavorite: nextFavorite });
  };

  // Toggle Completed Status with Confetti
  const handleToggleCompleted = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowContextMenu(false);

    if (manga.readingStatus === 'completed') {
      // Revert to reading
      await onUpdate(manga.id, { readingStatus: 'reading' });
    } else {
      // Mark as completed
      const updates: Partial<MangaItem> = {
        readingStatus: 'completed',
      };
      if (manga.totalChapters) {
        updates.currentChapter = manga.totalChapters;
      }
      await onUpdate(manga.id, updates);

      // Trigger completion celebration confetti
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#e11d48', '#10b981', '#f59e0b', '#3b82f6'],
      });
    }
  };

  // Quick +1 chapter
  const handleQuickAddChapter = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextChapter = manga.currentChapter + 1;
    const updates: Partial<MangaItem> = { currentChapter: nextChapter };

    if (manga.totalChapters && nextChapter >= manga.totalChapters && manga.readingStatus !== 'completed') {
      updates.readingStatus = 'completed';
      confetti({
        particleCount: 60,
        spread: 55,
        origin: { y: 0.7 },
      });
    }
    await onUpdate(manga.id, updates);
  };

  // Change status from menu
  const handleChangeStatus = async (status: ReadingStatus, e: React.MouseEvent) => {
    e.stopPropagation();
    setShowContextMenu(false);
    await onUpdate(manga.id, { readingStatus: status });
    if (status === 'completed') {
      confetti({
        particleCount: 60,
        spread: 50,
        origin: { y: 0.7 },
      });
    }
  };

  // Copy Manga Link
  const handleCopyLink = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(manga.sourceUrl);
      setCopiedLink(true);
      setTimeout(() => {
        setCopiedLink(false);
        setShowContextMenu(false);
      }, 1500);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  const handleDownloadCover = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowContextMenu(false);
    downloadCoverImage(manga.coverUrl, manga.title);
  };

  const handleDirectRead = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowContextMenu(false);
    window.open(manga.sourceUrl, '_blank', 'noopener,noreferrer');
  };

  const handleRightClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setShowContextMenu(true);
  };

  const isCompleted = manga.readingStatus === 'completed';
  const progressPct = manga.totalChapters
    ? Math.min(100, Math.round((manga.currentChapter / manga.totalChapters) * 100))
    : null;

  // Context Menu Dropdown Component
  const renderContextMenu = () => (
    <div
      ref={menuRef}
      onClick={(e) => e.stopPropagation()}
      className="absolute top-10 right-2 z-50 w-52 rounded-2xl bg-neutral-900 border border-neutral-700/80 shadow-2xl py-1.5 text-xs text-neutral-200 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150"
    >
      {/* Favorite item */}
      <button
        onClick={handleToggleFavorite}
        className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-neutral-800 transition text-left"
      >
        <span className="flex items-center gap-2">
          <Heart className={`w-3.5 h-3.5 ${manga.isFavorite ? 'fill-rose-500 text-rose-500' : 'text-neutral-400'}`} />
          <span>{manga.isFavorite ? 'Remove Favorite' : 'Add to Favorites'}</span>
        </span>
        {manga.isFavorite && <span className="text-[10px] text-rose-400 font-bold">Favorited</span>}
      </button>

      {/* Completed toggle item */}
      <button
        onClick={handleToggleCompleted}
        className="w-full flex items-center justify-between px-3.5 py-2 hover:bg-neutral-800 transition text-left"
      >
        <span className="flex items-center gap-2">
          <CheckCircle2 className={`w-3.5 h-3.5 ${isCompleted ? 'text-emerald-400' : 'text-neutral-400'}`} />
          <span>{isCompleted ? 'Mark as In-Progress' : 'Mark as Completed'}</span>
        </span>
        {isCompleted && <span className="text-[10px] text-emerald-400 font-bold">Done</span>}
      </button>

      {/* Quick Status Submenu */}
      <div className="px-3.5 py-1.5 border-t border-neutral-800 text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
        Change Status
      </div>
      <div className="px-2 pb-1 grid grid-cols-2 gap-1 text-[11px]">
        {(['reading', 'plan_to_read', 'on_hold', 'completed'] as ReadingStatus[]).map((st) => (
          <button
            key={st}
            onClick={(e) => handleChangeStatus(st, e)}
            className={`px-2 py-1 rounded-lg text-left capitalize transition ${
              manga.readingStatus === st
                ? 'bg-neutral-800 text-white font-bold'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
            }`}
          >
            {st.replace(/_/g, ' ')}
          </button>
        ))}
      </div>

      <div className="border-t border-neutral-800 my-1" />

      {/* Add Chapter */}
      <button
        onClick={handleQuickAddChapter}
        className="w-full flex items-center gap-2 px-3.5 py-2 hover:bg-neutral-800 transition text-left"
      >
        <Plus className="w-3.5 h-3.5 text-neutral-400" />
        <span>Read Next Chapter (+1)</span>
      </button>

      {/* Read Source */}
      <button
        onClick={handleDirectRead}
        className="w-full flex items-center gap-2 px-3.5 py-2 hover:bg-neutral-800 transition text-left"
      >
        <ExternalLink className="w-3.5 h-3.5 text-neutral-400" />
        <span>Read on {manga.sourceSite}</span>
      </button>

      {/* Copy Link */}
      <button
        onClick={handleCopyLink}
        className="w-full flex items-center gap-2 px-3.5 py-2 hover:bg-neutral-800 transition text-left"
      >
        {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-neutral-400" />}
        <span>{copiedLink ? 'Link Copied!' : 'Copy Manga Link'}</span>
      </button>

      {/* Download Cover */}
      <button
        onClick={handleDownloadCover}
        className="w-full flex items-center gap-2 px-3.5 py-2 hover:bg-neutral-800 transition text-left"
      >
        <Download className="w-3.5 h-3.5 text-neutral-400" />
        <span>Download Cover Art</span>
      </button>

      <div className="border-t border-neutral-800 my-1" />

      {/* Full Details */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          setShowContextMenu(false);
          onOpenDetails(manga);
        }}
        className="w-full flex items-center gap-2 px-3.5 py-2 hover:bg-neutral-800 text-neutral-300 hover:text-white transition text-left"
      >
        <Info className="w-3.5 h-3.5 text-neutral-400" />
        <span>Full Details & Dossier</span>
      </button>
    </div>
  );

  // 1. LIST VIEW LAYOUT
  if (view === 'list') {
    return (
      <div
        onClick={() => onOpenDetails(manga)}
        onContextMenu={handleRightClick}
        className="group relative flex items-center gap-4 p-3 rounded-2xl bg-neutral-900/80 hover:bg-neutral-850/90 border border-neutral-800/80 hover:border-neutral-700 transition cursor-pointer backdrop-blur-md shadow-lg"
      >
        {/* Thumbnail */}
        <div className="relative w-16 h-22 sm:w-20 sm:h-28 shrink-0 rounded-xl overflow-hidden bg-neutral-950 border border-neutral-800">
          <img
            src={`/api/proxy-image?url=${encodeURIComponent(manga.coverUrl)}`}
            alt={manga.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            onError={(e) => {
              (e.target as HTMLImageElement).src = manga.coverUrl;
            }}
          />
          {manga.isAdult && (
            <div className="absolute top-1 left-1 px-1 py-0.2 rounded bg-rose-600 text-[8px] font-black text-white">
              18+
            </div>
          )}
          {isCompleted && (
            <div className="absolute bottom-1 right-1 p-0.5 rounded-full bg-emerald-500 text-white shadow">
              <Check className="w-2.5 h-2.5 stroke-[3]" />
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <h3 className="text-sm sm:text-base font-bold text-white truncate group-hover:text-rose-400 transition">
              {manga.title}
            </h3>
            {manga.isFavorite && <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500 shrink-0" />}
            {isCompleted && (
              <span className="px-1.5 py-0.2 rounded bg-emerald-950 border border-emerald-700/60 text-emerald-300 text-[10px] font-bold">
                Completed
              </span>
            )}
          </div>
          <p className="text-xs text-neutral-400 truncate mb-1.5">
            {manga.author} • <span className="text-neutral-500">{manga.sourceSite}</span>
          </p>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="px-2 py-0.5 rounded-md bg-neutral-800 text-neutral-300 font-medium text-[11px]">
              Ch. {manga.currentChapter} {manga.totalChapters ? `/ ${manga.totalChapters}` : ''}
            </span>
            <span className="px-1.5 py-0.5 rounded-md bg-amber-500/10 text-amber-300 font-medium text-[11px] flex items-center gap-1">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              {manga.rating}
            </span>
            <span className="capitalize text-neutral-400 text-[11px] hidden sm:inline">
              ● {manga.readingStatus.replace(/_/g, ' ')}
            </span>
          </div>
        </div>

        {/* Hover / Action Icons Toolkit */}
        <div className="flex items-center gap-1.5 pr-2" onClick={(e) => e.stopPropagation()}>
          {/* Quick Favorite Icon */}
          <button
            onClick={handleToggleFavorite}
            className={`p-2 rounded-xl transition border ${
              manga.isFavorite
                ? 'bg-rose-950/80 border-rose-600 text-rose-400'
                : 'bg-neutral-800/80 border-neutral-700 text-neutral-400 hover:text-white'
            }`}
            title={manga.isFavorite ? 'Remove Favorite' : 'Mark as Favorite'}
          >
            <Heart className={`w-3.5 h-3.5 ${manga.isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
          </button>

          {/* Quick Mark Completed Icon */}
          <button
            onClick={handleToggleCompleted}
            className={`p-2 rounded-xl transition border ${
              isCompleted
                ? 'bg-emerald-950/80 border-emerald-600 text-emerald-400'
                : 'bg-neutral-800/80 border-neutral-700 text-neutral-400 hover:text-white'
            }`}
            title={isCompleted ? 'Mark as In-Progress' : 'Mark as Completed'}
          >
            <CheckCircle2 className={`w-3.5 h-3.5 ${isCompleted ? 'text-emerald-400' : ''}`} />
          </button>

          {/* Quick +1 Chapter */}
          <button
            onClick={handleQuickAddChapter}
            className="p-2 rounded-xl bg-neutral-800/80 border border-neutral-700 hover:bg-neutral-700 text-neutral-200 transition"
            title="+1 Chapter Read"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>

          {/* Read button */}
          <button
            onClick={handleDirectRead}
            className="px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow transition flex items-center gap-1.5"
            style={{ backgroundColor: accentColor }}
            title={`Read on ${manga.sourceSite}`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Read</span>
          </button>

          {/* 3-dots Context Menu Button */}
          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowContextMenu(!showContextMenu);
              }}
              className="p-2 rounded-xl bg-neutral-800/80 border border-neutral-700 hover:bg-neutral-700 text-neutral-400 hover:text-white transition"
              title="More Actions"
            >
              <MoreVertical className="w-3.5 h-3.5" />
            </button>
            {showContextMenu && renderContextMenu()}
          </div>
        </div>
      </div>
    );
  }

  // 2. MAGAZINE CARDS VIEW
  if (view === 'cards') {
    return (
      <div
        onClick={() => onOpenDetails(manga)}
        onContextMenu={handleRightClick}
        className="group relative flex flex-col md:flex-row rounded-3xl bg-neutral-900/90 border border-neutral-800/80 hover:border-neutral-700 overflow-hidden cursor-pointer backdrop-blur-md shadow-xl transition-all duration-300 hover:-translate-y-1"
      >
        {/* Cover */}
        <div className="relative w-full md:w-56 h-64 md:h-auto shrink-0 overflow-hidden bg-neutral-950">
          <img
            src={`/api/proxy-image?url=${encodeURIComponent(manga.coverUrl)}`}
            alt={manga.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={(e) => {
              (e.target as HTMLImageElement).src = manga.coverUrl;
            }}
          />
          {manga.isAdult && (
            <div className="absolute top-3 left-3 px-2 py-0.5 rounded-md bg-rose-600/95 text-[10px] font-black text-white flex items-center gap-1 shadow">
              <ShieldAlert className="w-3 h-3" />
              18+ ADULT
            </div>
          )}

          {/* Top Quick Actions on Image */}
          <div className="absolute top-3 right-3 flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {/* Quick Favorite */}
            <button
              onClick={handleToggleFavorite}
              className={`p-2 rounded-full backdrop-blur-md border transition shadow ${
                manga.isFavorite
                  ? 'bg-rose-950/80 border-rose-600 text-rose-400'
                  : 'bg-black/60 border-neutral-700 text-neutral-300 hover:text-white'
              }`}
              title={manga.isFavorite ? 'Remove Favorite' : 'Toggle Favorite'}
            >
              <Heart className={`w-3.5 h-3.5 ${manga.isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
            </button>

            {/* Quick Completed */}
            <button
              onClick={handleToggleCompleted}
              className={`p-2 rounded-full backdrop-blur-md border transition shadow ${
                isCompleted
                  ? 'bg-emerald-950/90 border-emerald-500 text-emerald-400'
                  : 'bg-black/60 border-neutral-700 text-neutral-300 hover:text-white'
              }`}
              title={isCompleted ? 'Mark as In-Progress' : 'Mark as Completed'}
            >
              <CheckCircle2 className={`w-3.5 h-3.5 ${isCompleted ? 'text-emerald-400' : ''}`} />
            </button>

            {/* Context menu button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowContextMenu(!showContextMenu);
              }}
              className="p-2 rounded-full bg-black/60 border border-neutral-700 text-neutral-300 hover:text-white backdrop-blur-md transition shadow"
              title="More Actions"
            >
              <MoreVertical className="w-3.5 h-3.5" />
            </button>
            {showContextMenu && renderContextMenu()}
          </div>
        </div>

        {/* Details */}
        <div className="flex-1 p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-start justify-between gap-3 mb-1">
              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-rose-400 transition line-clamp-1">
                  {manga.title}
                </h3>
                {manga.originalTitle && (
                  <p className="text-xs text-neutral-400 italic">{manga.originalTitle}</p>
                )}
              </div>
              {isCompleted && (
                <span className="px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-600 text-emerald-300 text-xs font-bold shrink-0">
                  Completed
                </span>
              )}
            </div>

            <p className="text-xs text-neutral-400 mb-3">
              By <span className="text-neutral-200">{manga.author}</span> • {manga.sourceSite}
            </p>

            <div className="flex flex-wrap gap-1.5 mb-3">
              {manga.genres.slice(0, 5).map((g) => (
                <span key={g} className="px-2 py-0.5 rounded-md text-[10px] font-medium bg-neutral-800 text-neutral-300">
                  {g}
                </span>
              ))}
            </div>

            <p className="text-xs text-neutral-300 line-clamp-3 leading-relaxed mb-4">
              {manga.synopsis}
            </p>
          </div>

          <div className="pt-3 border-t border-neutral-800 flex items-center justify-between">
            <div className="text-xs text-neutral-400">
              Ch. <strong className="text-white">{manga.currentChapter}</strong> / {manga.totalChapters ?? 'Ongoing'}
            </div>

            <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
              <button
                onClick={handleToggleFavorite}
                className={`p-2 rounded-xl border transition ${
                  manga.isFavorite
                    ? 'bg-rose-950/70 border-rose-600 text-rose-400'
                    : 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white'
                }`}
                title="Toggle Favorite"
              >
                <Heart className={`w-3.5 h-3.5 ${manga.isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
              </button>

              <button
                onClick={handleToggleCompleted}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 ${
                  isCompleted
                    ? 'bg-emerald-950 border-emerald-600 text-emerald-300'
                    : 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:text-white'
                }`}
                title={isCompleted ? 'Mark In-Progress' : 'Mark as Completed'}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{isCompleted ? 'Finished' : 'Complete'}</span>
              </button>

              <button
                onClick={handleDownloadCover}
                className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-750 text-neutral-300 transition"
                title="Download Cover"
              >
                <Download className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={handleDirectRead}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white shadow-lg transition flex items-center gap-2"
                style={{ backgroundColor: accentColor }}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Read Live</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 3. DEFAULT POSTER GRID VIEW
  return (
    <div
      onClick={() => onOpenDetails(manga)}
      onContextMenu={handleRightClick}
      className="group relative flex flex-col rounded-2xl bg-neutral-900/80 hover:bg-neutral-850/90 border border-neutral-800/80 hover:border-neutral-700/90 overflow-hidden cursor-pointer backdrop-blur-md shadow-lg transition-all duration-300 hover:-translate-y-1.5"
    >
      {/* Cover Image Container */}
      <div className="relative aspect-[3/4.2] w-full overflow-hidden bg-neutral-950">
        <img
          src={`/api/proxy-image?url=${encodeURIComponent(manga.coverUrl)}`}
          alt={manga.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          onError={(e) => {
            (e.target as HTMLImageElement).src = manga.coverUrl;
          }}
        />

        {/* Dark Vignette Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/30 pointer-events-none" />

        {/* Top Badges & Instant Quick Action Icons (Always Visible / Accessible) */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between pointer-events-none z-10">
          <div className="flex items-center gap-1">
            {manga.isAdult ? (
              <div className="px-2 py-0.5 rounded-md bg-rose-600/95 text-[10px] font-black text-white flex items-center gap-1 shadow-md">
                <ShieldAlert className="w-3 h-3" />
                18+
              </div>
            ) : (
              <div className="px-2 py-0.5 rounded-md bg-neutral-900/85 backdrop-blur-md text-[10px] font-semibold text-neutral-300 shadow">
                {manga.demographic || 'Manga'}
              </div>
            )}
            {isCompleted && (
              <div className="px-1.5 py-0.5 rounded-md bg-emerald-600 text-[10px] font-bold text-white flex items-center gap-1 shadow">
                <Check className="w-2.5 h-2.5 stroke-[3]" />
                <span>Done</span>
              </div>
            )}
          </div>

          {/* Quick Action Top Bar: Favorite, Completed, 3-Dots */}
          <div className="flex items-center gap-1 pointer-events-auto" onClick={(e) => e.stopPropagation()}>
            {/* Quick Favorite Button */}
            <button
              onClick={handleToggleFavorite}
              className={`p-1.5 rounded-xl backdrop-blur-md border transition shadow-md ${
                manga.isFavorite
                  ? 'bg-rose-950/90 border-rose-500 text-rose-300'
                  : 'bg-black/60 border-neutral-700/80 text-neutral-300 hover:text-white hover:bg-black/80'
              }`}
              title={manga.isFavorite ? 'Remove Favorite' : 'Mark as Favorite'}
            >
              <Heart className={`w-3.5 h-3.5 ${manga.isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
            </button>

            {/* Quick Mark as Completed Button */}
            <button
              onClick={handleToggleCompleted}
              className={`p-1.5 rounded-xl backdrop-blur-md border transition shadow-md ${
                isCompleted
                  ? 'bg-emerald-950/90 border-emerald-500 text-emerald-300'
                  : 'bg-black/60 border-neutral-700/80 text-neutral-300 hover:text-emerald-300 hover:bg-black/80'
              }`}
              title={isCompleted ? 'Mark as In-Progress' : 'Mark as Completed'}
            >
              <CheckCircle2 className={`w-3.5 h-3.5 ${isCompleted ? 'text-emerald-400' : ''}`} />
            </button>

            {/* 3-dots Context Menu Button */}
            <div className="relative">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowContextMenu(!showContextMenu);
                }}
                className="p-1.5 rounded-xl bg-black/60 border border-neutral-700/80 text-neutral-300 hover:text-white hover:bg-black/80 backdrop-blur-md transition shadow-md"
                title="Options menu"
              >
                <MoreVertical className="w-3.5 h-3.5" />
              </button>
              {showContextMenu && renderContextMenu()}
            </div>
          </div>
        </div>

        {/* Hover Quick Action Overlay */}
        <div className="absolute inset-0 bg-black/65 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex flex-col justify-end p-3 pointer-events-none z-10">
          <div className="flex items-center gap-1.5 pointer-events-auto">
            <button
              onClick={handleDirectRead}
              className="flex-1 py-2 px-2.5 rounded-xl text-xs font-bold text-white shadow-lg transition flex items-center justify-center gap-1.5"
              style={{ backgroundColor: accentColor }}
              title={`Read live on ${manga.sourceSite}`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Read</span>
              <ExternalLink className="w-3 h-3" />
            </button>

            {/* Mark Completed shortcut on hover */}
            <button
              onClick={handleToggleCompleted}
              className={`p-2 rounded-xl border transition shadow ${
                isCompleted
                  ? 'bg-emerald-900 border-emerald-500 text-emerald-300'
                  : 'bg-neutral-900/90 hover:bg-neutral-800 text-neutral-200 border-neutral-700'
              }`}
              title={isCompleted ? 'Mark as In-Progress' : 'Mark as Completed'}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
            </button>

            {/* Download Cover */}
            <button
              onClick={handleDownloadCover}
              className="p-2 rounded-xl bg-neutral-900/90 hover:bg-neutral-800 text-white transition border border-neutral-700 shadow"
              title="Download Cover Art"
            >
              <Download className="w-3.5 h-3.5" />
            </button>

            {/* +1 Chapter */}
            <button
              onClick={handleQuickAddChapter}
              className="p-2 rounded-xl bg-neutral-900/90 hover:bg-neutral-800 text-white transition border border-neutral-700 shadow"
              title="+1 Chapter Read"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Bottom Floating Stats */}
        <div className="absolute bottom-2.5 left-2.5 right-2.5 flex items-center justify-between text-xs pointer-events-none">
          <span className="px-2 py-0.5 rounded-md bg-black/65 backdrop-blur-md text-[10px] font-bold text-amber-300 flex items-center gap-1">
            <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
            {manga.rating}
          </span>
          <span className="px-2 py-0.5 rounded-md bg-black/65 backdrop-blur-md text-[10px] font-medium text-neutral-200">
            Ch. {manga.currentChapter} {manga.totalChapters ? `/ ${manga.totalChapters}` : ''}
          </span>
        </div>

        {/* Progress Bar */}
        {progressPct !== null && (
          <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-neutral-800/90">
            <div
              className={`h-full transition-all duration-300 ${isCompleted ? 'bg-emerald-500' : ''}`}
              style={{
                width: `${progressPct}%`,
                backgroundColor: isCompleted ? '#10b981' : accentColor,
              }}
            />
          </div>
        )}
      </div>

      {/* Title & Info Footer */}
      <div className="p-3.5 space-y-1">
        <h3 className="text-sm font-bold text-white truncate group-hover:text-rose-400 transition" title={manga.title}>
          {manga.title}
        </h3>
        <div className="flex items-center justify-between text-xs text-neutral-400">
          <span className="truncate max-w-[120px] text-neutral-500">{manga.sourceSite}</span>
          <span
            className={`capitalize text-[11px] font-semibold ${
              isCompleted ? 'text-emerald-400' : 'text-neutral-400'
            }`}
          >
            {manga.readingStatus.replace(/_/g, ' ')}
          </span>
        </div>
      </div>
    </div>
  );
};
