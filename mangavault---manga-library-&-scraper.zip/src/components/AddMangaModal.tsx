import React, { useState } from 'react';
import { X, Link2, Sparkles, AlertCircle, CheckCircle2, ExternalLink, Download, BookOpen, Heart, ShieldAlert } from 'lucide-react';
import { MangaItem, ReadingStatus, ScrapedMangaResponse } from '../types';
import { downloadCoverImage } from '../lib/downloadHelper';

interface AddMangaModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddManga: (manga: Omit<MangaItem, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  accentColor: string;
}

const SAMPLE_LINKS = [
  { name: 'Solo Leveling', url: 'https://asuracomic.net/series/solo-leveling' },
  { name: 'Berserk (18+)', url: 'https://mangadex.org/title/801513ba-a712-4985-8c30-524e8b380fe8/berserk' },
  { name: 'One Piece', url: 'https://mangaplus.shueisha.co.jp/titles/100020' },
  { name: 'Chainsaw Man', url: 'https://mangadex.org/title/a77742c1-fad9-4027-981f-7088774732fb/chainsaw-man' },
  { name: 'Jujutsu Kaisen', url: 'https://mangapark.net/title/jujutsu-kaisen' },
];

export const AddMangaModal: React.FC<AddMangaModalProps> = ({ isOpen, onClose, onAddManga, accentColor }) => {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [scrapedData, setScrapedData] = useState<ScrapedMangaResponse | null>(null);
  const [readingStatus, setReadingStatus] = useState<ReadingStatus>('reading');
  const [isFavorite, setIsFavorite] = useState(false);
  const [currentChapter, setCurrentChapter] = useState(1);
  const [personalNotes, setPersonalNotes] = useState('');
  const [saving, setSaving] = useState(false);

  if (!isOpen) return null;

  const handlePasteClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text && text.startsWith('http')) {
        setUrl(text.trim());
      }
    } catch (e) {
      // Clipboard read blocked, focus input
      const el = document.getElementById('manga-url-input');
      el?.focus();
    }
  };

  const handleFetchMetadata = async (targetUrl?: string) => {
    const urlToFetch = (typeof targetUrl === 'string' ? targetUrl : url).trim();
    if (!urlToFetch) return;

    if (targetUrl) {
      setUrl(targetUrl);
    }

    setLoading(true);
    setError(null);
    setScrapedData(null);

    try {
      const res = await fetch('/api/scrape-manga', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: urlToFetch }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to extract manga details from the provided link');
      }

      const data: ScrapedMangaResponse = await res.json();
      setScrapedData(data);
      if (data.totalChapters && data.totalChapters > 0) {
        setCurrentChapter(1);
      }
    } catch (err) {
      setError((err as Error).message || 'Unable to scrape manga info. Please check the URL.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!scrapedData) return;
    setSaving(true);
    try {
      await onAddManga({
        title: scrapedData.title,
        originalTitle: scrapedData.originalTitle || '',
        coverUrl: scrapedData.coverUrl,
        sourceUrl: scrapedData.sourceUrl || url,
        sourceSite: scrapedData.sourceSite || 'Web',
        author: scrapedData.author || 'Unknown',
        artist: scrapedData.artist || '',
        synopsis: scrapedData.synopsis || '',
        genres: scrapedData.genres || ['Manga'],
        status: scrapedData.status || 'ongoing',
        isAdult: Boolean(scrapedData.isAdult),
        totalChapters: scrapedData.totalChapters || null,
        currentChapter: Number(currentChapter) || 1,
        rating: scrapedData.rating || 8.5,
        readingStatus: readingStatus,
        notes: personalNotes,
        isFavorite: isFavorite,
        demographic: scrapedData.demographic || (scrapedData.isAdult ? 'Adult / 18+' : 'Seinen'),
      });
      // Reset & close
      setUrl('');
      setScrapedData(null);
      setPersonalNotes('');
      onClose();
    } catch (err) {
      setError('Failed to save manga to library. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center text-white shadow-md"
              style={{ backgroundColor: accentColor }}
            >
              <Link2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Add Manga From URL</h2>
              <p className="text-xs text-neutral-400">Paste any manga reader link to automatically fetch full details</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6">
          {/* Input Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleFetchMetadata();
            }}
            className="space-y-3"
          >
            <label htmlFor="manga-url-input" className="block text-xs font-semibold uppercase tracking-wider text-neutral-300">
              Manga / Webtoon Website URL
            </label>
            <div className="relative flex items-center">
              <input
                id="manga-url-input"
                type="url"
                required
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://mangadex.org/title/... or https://asuracomic.net/..."
                className="w-full pl-4 pr-32 py-3 bg-neutral-950 border border-neutral-700 focus:border-neutral-500 rounded-xl text-sm text-white placeholder-neutral-500 focus:outline-none transition shadow-inner"
              />
              <div className="absolute right-2 flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handlePasteClipboard}
                  className="px-2.5 py-1.5 text-xs font-medium rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition"
                >
                  Paste
                </button>
                <button
                  type="submit"
                  disabled={loading || !url.trim()}
                  className="px-3.5 py-1.5 text-xs font-semibold rounded-lg text-white transition disabled:opacity-50 flex items-center gap-1.5 shadow"
                  style={{ backgroundColor: accentColor }}
                >
                  {loading ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Fetching...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Extract</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Quick Sample Links */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-xs text-neutral-500">Quick Test (1-Click):</span>
              {SAMPLE_LINKS.map((sample) => (
                <button
                  key={sample.name}
                  type="button"
                  onClick={() => {
                    handleFetchMetadata(sample.url);
                  }}
                  className="px-2.5 py-1 text-xs rounded-lg bg-neutral-800/80 hover:bg-neutral-700 text-neutral-200 transition border border-neutral-700/60 font-medium flex items-center gap-1 hover:border-neutral-500"
                >
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>{sample.name}</span>
                </button>
              ))}
            </div>
          </form>

          {/* Loading status details (Turbo Fast) */}
          {loading && (
            <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 text-center space-y-3 shadow-lg">
              <div className="flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
                <Sparkles className="w-4 h-4 animate-spin" />
                <span>Turbo Manga Intelligence Active</span>
              </div>
              <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full animate-pulse transition-all duration-300"
                  style={{ width: '85%', backgroundColor: accentColor }}
                />
              </div>
              <p className="text-xs text-neutral-300 font-medium">
                Instant OpenGraph &amp; Gemini Turbo metadata parsing in progress...
              </p>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="p-4 rounded-xl bg-rose-950/50 border border-rose-800/60 text-rose-200 text-xs flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold text-rose-300">Extraction Issue</p>
                <p>{error}</p>
              </div>
            </div>
          )}

          {/* Scraped Result Preview */}
          {scrapedData && (
            <div className="space-y-5 p-5 rounded-2xl bg-neutral-950 border border-neutral-800">
              <div className="flex flex-col sm:flex-row gap-5">
                {/* Cover Image Preview */}
                <div className="relative w-36 h-52 sm:w-40 sm:h-56 shrink-0 rounded-xl overflow-hidden border border-neutral-700 bg-neutral-900 group shadow-lg mx-auto sm:mx-0">
                  <img
                    src={`/api/proxy-image?url=${encodeURIComponent(scrapedData.coverUrl)}`}
                    alt={scrapedData.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = scrapedData.coverUrl;
                    }}
                  />
                  {scrapedData.isAdult && (
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-rose-600/90 text-[10px] font-black text-white flex items-center gap-1 shadow">
                      <ShieldAlert className="w-3 h-3" />
                      18+ ADULT
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={() => downloadCoverImage(scrapedData.coverUrl, scrapedData.title)}
                    className="absolute bottom-2 right-2 p-1.5 rounded-lg bg-black/75 hover:bg-black text-white text-xs opacity-0 group-hover:opacity-100 transition shadow"
                    title="Download this cover image"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Details */}
                <div className="flex-1 space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="text-lg font-bold text-white leading-snug">{scrapedData.title}</h3>
                      {scrapedData.originalTitle && (
                        <p className="text-xs text-neutral-400 italic">{scrapedData.originalTitle}</p>
                      )}
                    </div>
                    <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-neutral-800 text-neutral-300 border border-neutral-700 uppercase">
                      {scrapedData.status}
                    </span>
                  </div>

                  <div className="text-xs text-neutral-400 space-y-1">
                    <p><span className="text-neutral-500">Author:</span> {scrapedData.author} {scrapedData.artist && `• Artist: ${scrapedData.artist}`}</p>
                    <p><span className="text-neutral-500">Source:</span> {scrapedData.sourceSite} {scrapedData.totalChapters ? `• Chapters: ${scrapedData.totalChapters}` : ''}</p>
                  </div>

                  {/* Genres */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {scrapedData.genres.slice(0, 6).map((g) => (
                      <span key={g} className="px-2 py-0.5 rounded-md text-[10px] font-medium bg-neutral-800/90 text-neutral-300">
                        {g}
                      </span>
                    ))}
                  </div>

                  {/* Synopsis snippet */}
                  <p className="text-xs text-neutral-300 line-clamp-3 leading-relaxed pt-1">
                    {scrapedData.synopsis}
                  </p>
                </div>
              </div>

              {/* User Reading Configurations */}
              <div className="pt-3 border-t border-neutral-850 grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-neutral-400 mb-1">Reading Status</label>
                  <select
                    value={readingStatus}
                    onChange={(e) => setReadingStatus(e.target.value as ReadingStatus)}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none"
                  >
                    <option value="reading">Currently Reading</option>
                    <option value="plan_to_read">Plan to Read</option>
                    <option value="completed">Completed</option>
                    <option value="on_hold">On Hold</option>
                    <option value="dropped">Dropped</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-neutral-400 mb-1">Current Chapter</label>
                  <input
                    type="number"
                    min="0"
                    max={scrapedData.totalChapters || 9999}
                    value={currentChapter}
                    onChange={(e) => setCurrentChapter(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-2 pt-5">
                  <button
                    type="button"
                    onClick={() => setIsFavorite(!isFavorite)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border transition ${
                      isFavorite
                        ? 'bg-rose-950/60 border-rose-700 text-rose-300'
                        : 'bg-neutral-900 border-neutral-700 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
                    <span>{isFavorite ? 'Favorite' : 'Mark Favorite'}</span>
                  </button>
                </div>
              </div>

              {/* Personal Notes */}
              <div>
                <label className="block text-[11px] font-medium text-neutral-400 mb-1">Personal Note / Review (Optional)</label>
                <textarea
                  rows={2}
                  value={personalNotes}
                  onChange={(e) => setPersonalNotes(e.target.value)}
                  placeholder="e.g. Recommended by a friend, started at chapter 1..."
                  className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs text-white focus:outline-none resize-none placeholder-neutral-500"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-2">
                <a
                  href={scrapedData.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Preview Website</span>
                </a>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setScrapedData(null)}
                    className="px-4 py-2 rounded-xl text-xs font-medium text-neutral-400 hover:text-white transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={saving}
                    onClick={handleSave}
                    className="px-6 py-2.5 rounded-xl text-xs font-bold text-white shadow-lg transition flex items-center gap-2 disabled:opacity-50"
                    style={{ backgroundColor: accentColor }}
                  >
                    {saving ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Saving...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Add To Library</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
