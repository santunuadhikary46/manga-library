import React, { useState } from 'react';
import { Sparkles, Plus, Palette, Search, Cloud, CloudCheck, LogIn, LogOut, ShieldAlert, Play, LayoutGrid, List, Layers } from 'lucide-react';
import { User } from '../lib/firebase';
import { LayoutView } from '../types';

interface NavbarProps {
  user: User | null;
  onSignIn: () => void;
  onSignOut: () => void;
  onOpenAddModal: () => void;
  onOpenCustomizer: () => void;
  onReplayIntro: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  allowAdultContent: boolean;
  onToggleAdult: () => void;
  layoutView: LayoutView;
  onChangeLayout: (view: LayoutView) => void;
  accentColor: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  onSignIn,
  onSignOut,
  onOpenAddModal,
  onOpenCustomizer,
  onReplayIntro,
  searchQuery,
  onSearchChange,
  allowAdultContent,
  onToggleAdult,
  layoutView,
  onChangeLayout,
  accentColor,
}) => {
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-neutral-950/85 backdrop-blur-xl border-b border-neutral-800/80 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
        {/* Logo and Kanji Badge */}
        <div className="flex items-center gap-3">
          <div
            onClick={onReplayIntro}
            className="w-10 h-10 rounded-2xl flex items-center justify-center font-black text-lg text-white shadow-lg cursor-pointer transition hover:scale-105"
            style={{ backgroundColor: accentColor }}
            title="Click to replay entrance animation"
          >
            庫
          </div>
          <div className="hidden sm:block">
            <span className="text-lg font-black tracking-tight text-white">
              MANGA<span style={{ color: accentColor }}>VAULT</span>
            </span>
            <span className="block text-[10px] text-neutral-400 font-medium -mt-1 tracking-wider uppercase">
              Smart Cloud Library
            </span>
          </div>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-md mx-2 sm:mx-4">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search title, author, or genre..."
              className="w-full pl-9 pr-4 py-2 bg-neutral-900/90 border border-neutral-800 focus:border-neutral-600 rounded-full text-xs text-white placeholder-neutral-500 focus:outline-none transition shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 text-xs text-neutral-500 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Right Action Toolkit */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Add Manga Button */}
          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white shadow-lg transition hover:brightness-110 active:scale-95 shrink-0"
            style={{ backgroundColor: accentColor }}
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span className="hidden md:inline">Paste URL</span>
          </button>

          {/* Adult 18+ Toggle */}
          <button
            onClick={onToggleAdult}
            className={`p-2 rounded-xl text-xs font-bold transition flex items-center gap-1 border shrink-0 ${
              allowAdultContent
                ? 'bg-rose-950/70 border-rose-800/80 text-rose-300'
                : 'bg-neutral-900 border-neutral-800 text-neutral-500 hover:text-neutral-300'
            }`}
            title={allowAdultContent ? '18+ Adult content shown' : '18+ Adult content hidden'}
          >
            <ShieldAlert className="w-4 h-4" />
            <span className="hidden lg:inline">{allowAdultContent ? '18+ On' : '18+ Off'}</span>
          </button>

          {/* Layout switcher */}
          <div className="hidden sm:flex items-center bg-neutral-900 border border-neutral-800 rounded-xl p-0.5">
            <button
              onClick={() => onChangeLayout('grid')}
              className={`p-1.5 rounded-lg transition ${
                layoutView === 'grid' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
              }`}
              title="Poster Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => onChangeLayout('list')}
              className={`p-1.5 rounded-lg transition ${
                layoutView === 'list' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
              }`}
              title="Compact List View"
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => onChangeLayout('cards')}
              className={`p-1.5 rounded-lg transition ${
                layoutView === 'cards' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
              }`}
              title="Magazine Cards View"
            >
              <Layers className="w-4 h-4" />
            </button>
          </div>

          {/* Wallpaper / Customization Button */}
          <button
            onClick={onOpenCustomizer}
            className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 text-neutral-300 hover:text-white transition shadow shrink-0"
            title="Custom Wallpapers & Theme"
          >
            <Palette className="w-4 h-4" />
          </button>

          {/* User / Google Sign-in Account */}
          <div className="relative">
            {user ? (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2 p-1 pl-1.5 sm:pr-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 transition"
                >
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt="Avatar"
                      className="w-7 h-7 rounded-lg object-cover border border-neutral-700"
                    />
                  ) : (
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold text-white"
                      style={{ backgroundColor: accentColor }}
                    >
                      {user.displayName?.[0] || 'U'}
                    </div>
                  )}
                  <span className="hidden sm:inline text-xs font-medium text-white max-w-[100px] truncate">
                    {user.displayName?.split(' ')[0] || 'Account'}
                  </span>
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" title="Cloud Synced" />
                </button>

                {/* Dropdown Menu */}
                {showUserMenu && (
                  <div className="absolute right-0 top-12 w-56 rounded-2xl bg-neutral-900 border border-neutral-800 shadow-2xl p-2 z-50 text-xs">
                    <div className="px-3 py-2 border-b border-neutral-800 mb-1">
                      <p className="font-bold text-white truncate">{user.displayName || 'Manga Reader'}</p>
                      <p className="text-neutral-400 truncate text-[11px]">{user.email}</p>
                      <div className="flex items-center gap-1 text-[10px] text-emerald-400 mt-1">
                        <Cloud className="w-3 h-3" />
                        <span>Cloud Library Synced</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onReplayIntro();
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-neutral-300 hover:text-white hover:bg-neutral-800 transition flex items-center gap-2"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>Replay Opening Animation</span>
                    </button>

                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onSignOut();
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-rose-400 hover:bg-rose-950/40 transition flex items-center gap-2 mt-1"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onSignIn}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-700/80 text-neutral-200 text-xs font-semibold transition shadow shrink-0"
                title="Sign in with Google to enable Cloud synchronization"
              >
                <LogIn className="w-3.5 h-3.5 text-rose-400" />
                <span className="hidden sm:inline">Google Cloud Sync</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
