import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, BookOpen, ChevronRight } from 'lucide-react';

interface SplashAnimationProps {
  onComplete: () => void;
  accentColor?: string;
}

export const SplashAnimation: React.FC<SplashAnimationProps> = ({ onComplete, accentColor = '#e11d48' }) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Auto complete after 2.8s if not manually dismissed
    const timer = setTimeout(() => {
      handleDismiss();
    }, 2800);
    return () => clearTimeout(timer);
  }, []);

  const handleDismiss = () => {
    setIsVisible(false);
    setTimeout(onComplete, 500);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.5, ease: 'easeInOut' }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black overflow-hidden select-none"
          onClick={handleDismiss}
        >
          {/* Animated Speed Lines Background */}
          <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-neutral-800 via-neutral-950 to-black">
            <div className="w-full h-full bg-[repeating-conic-gradient(#fff_0deg_1deg,transparent_1deg_10deg)] opacity-10 animate-[spin_60s_linear_infinite]" />
          </div>

          {/* Central Logo & Kanji presentation */}
          <div className="relative z-10 flex flex-col items-center text-center px-4 max-w-lg">
            {/* Dramatic Japanese Calligraphy badge */}
            <motion.div
              initial={{ scale: 0, rotate: -15, opacity: 0 }}
              animate={{ scale: 1, rotate: 0, opacity: 1 }}
              transition={{ type: 'spring', damping: 12, stiffness: 120, delay: 0.1 }}
              className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-neutral-900/90 border border-neutral-700/80 shadow-2xl mb-6 relative group"
              style={{ boxShadow: `0 0 35px ${accentColor}40` }}
            >
              <span className="text-4xl font-black text-rose-500 tracking-wider">
                漫画
              </span>
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
                className="absolute -top-1 -right-1"
              >
                <Sparkles className="w-5 h-5 text-amber-400" />
              </motion.div>
            </motion.div>

            {/* Title Reveal */}
            <motion.h1
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.35, duration: 0.6 }}
              className="text-4xl sm:text-5xl font-black tracking-tight text-white mb-2"
            >
              MANGA<span style={{ color: accentColor }}>VAULT</span>
            </motion.h1>

            {/* Subtitle / Description */}
            <motion.p
              initial={{ y: 15, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.55, duration: 0.5 }}
              className="text-sm sm:text-base text-neutral-400 font-medium tracking-wide mb-6 flex items-center gap-2"
            >
              <BookOpen className="w-4 h-4 text-neutral-400 inline" />
              Smart URL Scraper • Cloud Sync • Offline Reader
            </motion.p>

            {/* Progress / Enter button */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.75, duration: 0.4 }}
              className="flex items-center gap-3"
            >
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDismiss();
                }}
                className="px-6 py-2.5 rounded-full text-sm font-semibold text-white shadow-lg transition-transform hover:scale-105 active:scale-95 flex items-center gap-2"
                style={{ backgroundColor: accentColor }}
              >
                <span>Enter Library</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </motion.div>

            <motion.div
              initial={{ width: 0 }}
              animate={{ width: '100%' }}
              transition={{ duration: 2.2, ease: 'easeInOut' }}
              className="h-0.5 mt-8 rounded-full opacity-60"
              style={{ backgroundColor: accentColor }}
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
