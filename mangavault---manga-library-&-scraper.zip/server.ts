import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// High-speed in-memory cache for extracted manga metadata
const mangaCache = new Map<string, any>();


app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Initialize Google Gemini SDK
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to sanitize filenames
function sanitizeFilename(name: string): string {
  return name.replace(/[^a-zA-Z0-9_\-\u0900-\u097F]/g, '_').slice(0, 80) || 'manga_cover';
}

// Scrape and extract metadata endpoint
// Scrape and extract metadata endpoint (Turbo Fast)
app.post('/api/scrape-manga', async (req, res) => {
  const { url } = req.body;

  if (!url || typeof url !== 'string' || !url.startsWith('http')) {
    return res.status(400).json({ error: 'Please provide a valid manga web URL starting with http:// or https://' });
  }

  const cleanUrl = url.trim();

  // Instant response from memory cache if already extracted
  if (mangaCache.has(cleanUrl)) {
    return res.json(mangaCache.get(cleanUrl));
  }

  let scrapedTitle = '';
  let scrapedOgImage = '';
  let scrapedOgDesc = '';
  let scrapedAuthor = '';
  let hostname = '';

  try {
    const parsedUrl = new URL(cleanUrl);
    hostname = parsedUrl.hostname.replace(/^www\./, '');

    // Ultra-fast 3.5s timeout for fetching HTML head metadata
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3500);

    const pageRes = await fetch(cleanUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9,ja;q=0.8,ko;q=0.7',
      },
    });
    clearTimeout(timeout);

    if (pageRes.ok) {
      // Only read first 35KB - sufficient for head, og-tags, and title
      const htmlText = await pageRes.text();
      const headSection = htmlText.slice(0, 35000);

      // Fast regex extraction
      const titleMatch = headSection.match(/<title[^>]*>([^<]+)<\/title>/i);
      if (titleMatch) scrapedTitle = titleMatch[1].trim();

      const ogImageMatch = headSection.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i) ||
                           headSection.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i);
      if (ogImageMatch) scrapedOgImage = ogImageMatch[1].trim();

      const ogDescMatch = headSection.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i) ||
                          headSection.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i);
      if (ogDescMatch) scrapedOgDesc = ogDescMatch[1].trim();

      const authorMatch = headSection.match(/<meta[^>]+name=["']author["'][^>]+content=["']([^"']+)["']/i) ||
                          headSection.match(/<meta[^>]+property=["']article:author["'][^>]+content=["']([^"']+)["']/i);
      if (authorMatch) scrapedAuthor = authorMatch[1].trim();
    }
  } catch (fetchErr) {
    // URL analysis will handle fallback seamlessly
  }

  try {
    // Compact, high-efficiency prompt with minimal token overhead
    const prompt = `Extract manga/comic metadata fast for:
URL: ${cleanUrl}
Domain: ${hostname}
Scraped Title: ${scrapedTitle}
Scraped Image: ${scrapedOgImage}
Scraped Desc: ${scrapedOgDesc}
Scraped Author: ${scrapedAuthor}

Output accurate:
- title (clean English/Romaji title)
- originalTitle (native script or alternate)
- author & artist
- synopsis (concise summary)
- coverUrl (use scraped image or high-res poster)
- genres (array of genres)
- status (ongoing/completed/hiatus/unknown)
- isAdult (true if 18+, mature, ecchi, smut, explicit, gore; else false)
- totalChapters (number or null)
- rating (0-10)
- demographic (Shounen, Seinen, Shoujo, Josei, Adult)
- sourceSite (${hostname || 'Web'})`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            originalTitle: { type: Type.STRING },
            author: { type: Type.STRING },
            artist: { type: Type.STRING },
            synopsis: { type: Type.STRING },
            coverUrl: { type: Type.STRING },
            genres: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            status: { type: Type.STRING, enum: ['ongoing', 'completed', 'hiatus', 'unknown'] },
            isAdult: { type: Type.BOOLEAN },
            totalChapters: { type: Type.INTEGER },
            rating: { type: Type.NUMBER },
            demographic: { type: Type.STRING },
            sourceSite: { type: Type.STRING },
          },
          required: ['title', 'synopsis', 'coverUrl', 'genres', 'status', 'isAdult'],
        },
      },
    });

    const parsedData = JSON.parse(response.text || '{}');

    let coverUrl = parsedData.coverUrl || scrapedOgImage || '';
    if (!coverUrl || coverUrl.includes('placeholder') || (!coverUrl.startsWith('http://') && !coverUrl.startsWith('https://'))) {
      if (scrapedOgImage && scrapedOgImage.startsWith('http')) {
        coverUrl = scrapedOgImage;
      } else {
        coverUrl = `https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=80`;
      }
    }

    const result = {
      title: parsedData.title || scrapedTitle || 'Manga Title',
      originalTitle: parsedData.originalTitle || '',
      author: parsedData.author || scrapedAuthor || 'Unknown Author',
      artist: parsedData.artist || parsedData.author || 'Unknown Artist',
      synopsis: parsedData.synopsis || scrapedOgDesc || 'No synopsis provided.',
      coverUrl: coverUrl,
      genres: Array.isArray(parsedData.genres) && parsedData.genres.length > 0 ? parsedData.genres : ['Manga', 'Action'],
      status: parsedData.status || 'ongoing',
      isAdult: Boolean(parsedData.isAdult),
      totalChapters: parsedData.totalChapters || null,
      rating: typeof parsedData.rating === 'number' ? Math.min(10, Math.max(0, parsedData.rating)) : 8.5,
      demographic: parsedData.demographic || (parsedData.isAdult ? 'Adult / 18+' : 'Seinen'),
      sourceSite: parsedData.sourceSite || hostname || 'Web Reader',
      sourceUrl: cleanUrl,
    };

    // Store in cache for sub-millisecond future retrievals
    mangaCache.set(cleanUrl, result);

    return res.json(result);
  } catch (aiErr) {
    console.error('Fast fallback extraction:', aiErr);

    const fallbackTitle = scrapedTitle.replace(/\s*[-|–]\s*(Read|Manga|Chapter|Online).*/i, '').trim() ||
      cleanUrl.split('/').filter(Boolean).pop()?.replace(/[-_]/g, ' ') ||
      'Extracted Manga';

    const fallbackResult = {
      title: fallbackTitle,
      originalTitle: '',
      author: scrapedAuthor || 'Unknown',
      artist: 'Unknown',
      synopsis: scrapedOgDesc || 'Manga imported from link: ' + cleanUrl,
      coverUrl: scrapedOgImage || 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=80',
      genres: ['Manga', 'Action'],
      status: 'ongoing',
      isAdult: false,
      totalChapters: null,
      rating: 8.5,
      demographic: 'General',
      sourceSite: hostname || 'Web Reader',
      sourceUrl: cleanUrl,
    };

    mangaCache.set(cleanUrl, fallbackResult);
    return res.json(fallbackResult);
  }
});


// Proxy image endpoint to prevent hotlinking/CORS block from manga CDNs
app.get('/api/proxy-image', async (req, res) => {
  const { url } = req.query;
  if (!url || typeof url !== 'string' || !url.startsWith('http')) {
    return res.status(400).send('Invalid image URL');
  }

  try {
    const parsed = new URL(url);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 7000);

    const imageRes = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Referer': parsed.origin,
      },
    });
    clearTimeout(timeout);

    if (!imageRes.ok) {
      return res.redirect(302, url);
    }

    const contentType = imageRes.headers.get('content-type') || 'image/jpeg';
    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'public, max-age=604800, immutable');

    const buffer = await imageRes.arrayBuffer();
    return res.send(Buffer.from(buffer));
  } catch (err) {
    return res.redirect(302, url);
  }
});

// Download cover directly to user machine with Content-Disposition
app.get('/api/download-cover', async (req, res) => {
  const { url, title } = req.query;
  if (!url || typeof url !== 'string' || !url.startsWith('http')) {
    return res.status(400).send('Invalid cover URL');
  }

  try {
    const parsed = new URL(url);
    const imageRes = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Referer': parsed.origin,
      },
    });

    if (!imageRes.ok) {
      return res.status(502).send('Failed to fetch cover image from host');
    }

    const contentType = imageRes.headers.get('content-type') || 'image/jpeg';
    const ext = contentType.includes('png') ? 'png' : contentType.includes('webp') ? 'webp' : 'jpg';
    const cleanTitle = sanitizeFilename(String(title || 'manga'));

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${cleanTitle}-cover.${ext}"`);

    const buffer = await imageRes.arrayBuffer();
    return res.send(Buffer.from(buffer));
  } catch (err) {
    return res.status(500).send('Error downloading image');
  }
});

// Setup Vite or Static File serving
async function setupFrontend() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`MangaVault Server running on http://0.0.0.0:${PORT}`);
  });
}

setupFrontend().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
